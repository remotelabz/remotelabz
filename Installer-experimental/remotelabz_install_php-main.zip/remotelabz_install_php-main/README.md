# Installeur RemoteLabz

Ce projet permet d'automatiser l'installation de RemoteLabz sur deux machines virtuelles (Front et Worker) via une interface web en PHP.

## Arborescence

```bash
/remoteLabz-installer
├── public
│   ├── assets
│   │   ├── script.js               # JavaScript pour l'interface utilisateur
│   │   └── style.css               # Feuilles de style CSS
│   ├── includes
│   │   ├── composer.phar           # Gestionnaire de dépendances PHP
│   │   ├── config.php              # Configuration globale
│   │   ├── database.php            # Gestion de la base de données
│   │   ├── github_helper.php       # Fonctions pour interagir avec GitHub
│   │   ├── install.php             # Orchestration de l'installation
│   │   └── logger.php              # Gestion des logs
│   ├── install                     # Dossier d'installation
│   │   ├── requirements.php        # Vérification des prérequis
│   │   ├── db_config.php           # Configuration de la base de données
│   │   ├── dhcp_config.php         # Configuration du service DHCP
│   │   ├── rabbitmq_config.php     # Configuration de RabbitMQ
│   │   ├── openvpn_config.php      # Configuration d'OpenVPN
│   │   ├── exim4_config.php        # Configuration d'Exim4
│   │   ├── front_config.php        # Configuration du serveur Front
│   │   ├── worker_config.php       # Configuration du serveur Worker
│   │   ├── jwt_config.php          # Configuration des clés JWT
│   │   └── finalization.php        # Finalisation de l'installation
│   ├── logs                        # Dossier pour les fichiers de logs
│   │   └── install.log             # Fichier de logs de l'installation
│   ├── config                      # Dossier pour les fichiers de configuration
│   │   └── install.json            # Configuration sauvegardée de l'installation
│   ├── scripts
│   │   ├── check_requirements.sh   # Vérification des prérequis système
│   │   ├── connect_front.sh        # Connexion SSH à la machine Front
│   │   ├── connect_worker.sh       # Connexion SSH à la machine Worker
│   │   ├── install_front.sh        # Installation du Front
│   │   ├── install_local_worker.sh # Installation du Worker en local
│   │   ├── install_requirements.sh # Installation des prérequis
│   │   ├── install_worker.sh       # Installation du Worker
│   │   ├── configure_dhcp_service.sh # Configuration du service DHCP
│   │   ├── post_install.sh         # Scripts de post-installation
│   │   ├── test_ssh.sh             # Test de connexion SSH
│   │   └── test_ssh_script.sh      # Script de test pour SSH
│   ├── favicon.ico                 # Icône du site
│   ├── index.php                   # Page d'accueil pour lancer l'installation
│   └── install_result.php          # Page affichant les résultats de l'installation
├── .gitignore
└── README.md
```

## Documentation

### Fonctionnement

1. **Interface Web**  
   L'utilisateur accède à `public/index.php` qui présente un assistant d'installation en 10 étapes :

   - Étape 1 : Vérification des prérequis
   - Étape 2 : Configuration de la base de données MySQL
   - Étape 3 : Configuration d'OpenVPN
   - Étape 4 : Configuration du service DHCP
   - Étape 5 : Configuration de RabbitMQ
   - Étape 6 : Configuration d'Exim4
   - Étape 7 : Configuration des clés API (JWT)
   - Étape 8 : Configuration du serveur Front
   - Étape 9 : Configuration du serveur Worker
   - Étape 10 : Finalisation de l'installation

2. **Processus d'Installation**  
   Chaque étape est gérée par un fichier PHP correspondant dans le dossier `install/` :

   - Les informations saisies sont stockées en session
   - Des tests de connexion SSH sont effectués via `scripts/test_ssh.sh`
   - La vérification des prérequis est effectuée via `scripts/check_requirements.sh`
   - À l'étape finale (`finalization.php`), le script `includes/install.php` est appelé pour :
     - Se connecter à la machine Front via `scripts/connect_front.sh`
     - Installer le Front via `scripts/install_front.sh`
     - Si un Worker est configuré, se connecter via `scripts/connect_worker.sh`
     - Installer le Worker via `scripts/install_worker.sh` ou `scripts/install_local_worker.sh` (si même machine)
   - Les résultats sont affichés sur `install_result.php`

3. **Logs et Résultats**
   - Toutes les actions et erreurs sont enregistrées dans `logs/install.log` via `includes/logger.php`
   - La page `install_result.php` affiche :
     - Le statut de l'installation (succès/échec)
     - Les erreurs rencontrées
     - Les dernières lignes du journal d'installation
     - Des instructions spécifiques pour les installations standalone (Front et Worker sur la même machine)

4. **Service DHCP**
   - L'installeur permet désormais de configurer un service DHCP pour les laboratoires
   - Un conteneur spécial "Service" est utilisé pour fournir le DHCP dans chaque laboratoire
   - Après l'installation, le script `scripts/configure_dhcp_service.sh` permet de :
     - Configurer automatiquement le conteneur avec les bonnes adresses IP
     - Installer et configurer dnsmasq pour le service DHCP
     - Définir la plage d'IP à distribuer en fonction du réseau du laboratoire
   - Le service DHCP se configure avec l'adresse IP = IP_Passerelle - 1
     (Ex: si le réseau est 10.10.10.0/27, la passerelle sera 10.10.10.30 et le DHCP aura l'IP 10.10.10.29)

### Pré-requis

- Système Linux (Debian/Ubuntu recommandé)
- PHP 7.4 ou supérieur
- OpenSSL pour la génération des clés
- Accès SSH configuré pour les VM Front et Worker

### Exécution

1. Rendez les scripts exécutables :

   ```bash
   chmod +x public/scripts/*.sh
   ```

2. Exécutez le script d'installation des prérequis :

   ```bash
   sudo bash public/scripts/install_requirements.sh
   ```

3. Lancez le serveur PHP :

   ```bash
   php -S localhost:8000 -t public
   ```

4. Accédez à `http://localhost:8000` depuis votre navigateur.

### Configuration

L'installation requiert les informations suivantes :

- **Base de données** : Mot de passe root, nom de la base, utilisateur et mot de passe
- **RabbitMQ** : Utilisateur et mot de passe pour AMQP
- **OpenVPN** : Passphrase, réseau de base et masque réseau
- **DHCP** : État (activé/désactivé), réseau de base, masque CIDR, suffixe de passerelle
- **SSH** : Adresse publique, nom d'utilisateur et mot de passe
- **Système** : Email système et passphrase JWT
- **Worker** (optionnel) : Adresse du serveur, utilisateur SSH et mot de passe

### Configuration post-installation du service DHCP

Si vous avez activé le service DHCP lors de l'installation, suivez ces étapes après l'installation pour configurer le conteneur "Service" :

1. Dans l'interface de RemoteLabz, accédez au menu Sandbox
2. Démarrez le conteneur "Migration"
3. Récupérez l'ID du conteneur en cours d'exécution avec :
   ```bash
   docker ps | grep migration
   ```
4. Exécutez le script de configuration automatique :
   ```bash
   ./public/scripts/configure_dhcp_service.sh 10.10.10.0 27 30 <ID_CONTENEUR>
   ```
   où :
   - `10.10.10.0` est le réseau de base configuré
   - `27` est le masque CIDR (généralement 27 ou 24)
   - `30` est le suffixe de passerelle
   - `<ID_CONTENEUR>` est l'identifiant du conteneur Migration

5. Arrêtez le conteneur, puis exportez-le sous le nom "Service" via l'interface de RemoteLabz

Une fois configuré, ce conteneur "Service" pourra être ajouté à n'importe quel laboratoire pour fournir un service DHCP automatique adapté au réseau du laboratoire.
