function togglePasswordVisibility(id) {
    const input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
    } else {
        input.type = "password";
    }
}

async function fetchGitBranches() {
    const response = await fetch('https://api.github.com/repos/remotelabz/remotelabz/branches');
    const branches = await response.json();
    const branchSelect = document.getElementById('branch');

    branches.forEach(branch => {
        const option = document.createElement('option');
        option.value = branch.name;
        option.textContent = branch.name;
        branchSelect.appendChild(option);
    });
}

document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const loaderPopup = document.getElementById('loaderPopup');
    const loaderText = document.getElementById('loaderText');
    const loaderTimer = document.getElementById('loaderTimer');
    const loaderEstimate = document.getElementById('loaderEstimate');
    const messages = [
        "Veuillez patienter pendant l'installation...",
        "Gardez votre calme, installation en cours...",
        "Installation en cours, cela peut prendre quelques minutes...",
        "Configuration des paramètres, merci de patienter...",
        "Configuration des services, merci de patienter...",
        "Configuration des fichiers, merci de patienter...",
        "Test des différentes configurations, merci de patienter...",
        "Presque terminé, merci de patienter encore un peu..."
    ];
    let messageIndex = 0;
    let timer = 0;

    form.addEventListener('submit', function(event) {
        loaderPopup.style.display = 'flex';
        setInterval(function() {
            messageIndex = (messageIndex + 1) % messages.length;
            loaderText.textContent = messages[messageIndex];
        }, 10000);

        setInterval(function() {
            timer++;
            if (timer < 60) {
                loaderTimer.textContent = `Temps écoulé : ${timer}s`;
            } else {
                const minutes = Math.floor(timer / 60);
                const seconds = timer % 60;
                loaderTimer.textContent = `Temps écoulé : ${minutes}m ${seconds}s`;
            }
        }, 1000);
    });
});

document.addEventListener('DOMContentLoaded', fetchGitBranches);