<?php
session_start();
require_once __DIR__ . '/includes/install.php';

// Initialize or get current step
$currentStep = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$totalSteps = 10;

// Define installation steps
$steps = [
    1 => ['title' => 'Prérequis', 'file' => 'requirements.php'],
    2 => ['title' => 'Configuration de la base de données (MySQL)', 'file' => 'db_config.php'],
    3 => ['title' => 'Configuration d\'OpenVPN', 'file' => 'openvpn_config.php'],
    4 => ['title' => 'Configuration du service DHCP', 'file' => 'dhcp_config.php'],
    5 => ['title' => 'Configuration de RabbitMQ', 'file' => 'rabbitmq_config.php'],
    6 => ['title' => 'Configuration d\'Exim4', 'file' => 'exim4_config.php'],
    7 => ['title' => 'Configuration des clés API (JWT)', 'file' => 'jwt_config.php'],
    8 => ['title' => 'Configuration du Front', 'file' => 'front_config.php'],
    9 => ['title' => 'Configuration du Worker', 'file' => 'worker_config.php'],
    10 => ['title' => 'Finalisation', 'file' => 'finalization.php']
];

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation RemoteLabz - Étape <?php echo $currentStep; ?></title>
    <link rel="stylesheet" href="/assets/style.css">
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
</head>
<body>
    <div class="sidebar">
        <h2>Installation</h2>
        <ul class="stepper">
            <?php foreach ($steps as $stepNum => $step): ?>
            <li class="step <?php 
                if ($stepNum === $currentStep) echo 'active';
                elseif ($stepNum < $currentStep) echo 'completed';
                ?>" onclick="window.location.href='?step=<?php echo $stepNum; ?>'">
                <?php echo $step['title']; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="main-content">
        <div class="container">
            <?php
            $stepFile = __DIR__ . '/install/' . $steps[$currentStep]['file'];
            if (file_exists($stepFile)) {
                include $stepFile;
            } else {
                echo '<div class="error">Erreur : Page d\'installation non trouvée.</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>