<?php
// /remoteLabz-installer/includes/config.php

// Chemin vers le fichier de log
define('LOG_FILE', __DIR__ . '/../logs/install.log');

// Chemin vers les scripts Shell
define('SCRIPT_PATH', __DIR__ . '/../scripts/');

/**
 * Génère une clé API sécurisée.
 * @param int $length Longueur en octets (la clé finale sera en hexadécimal, donc 2*$length caractères).
 * @return string
 */
function generateApiKey($length = 16) {
    return bin2hex(random_bytes($length));
}
?>
