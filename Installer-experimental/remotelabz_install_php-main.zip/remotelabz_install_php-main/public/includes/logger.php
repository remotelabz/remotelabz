<?php
// /remoteLabz-installer/includes/logger.php
require_once 'config.php';

// Niveaux de log
define('LOG_LEVEL_DEBUG', 1);
define('LOG_LEVEL_INFO', 2);
define('LOG_LEVEL_WARNING', 3);
define('LOG_LEVEL_ERROR', 4);

// Configuration du niveau de log minimum (modifiez cette valeur pour voir plus ou moins de logs)
define('LOG_LEVEL_MIN', LOG_LEVEL_DEBUG);

/**
 * Écrit un message dans les logs avec un niveau spécifique
 * @param string $message Le message à logger
 * @param int $level Le niveau de log (DEBUG, INFO, WARNING, ERROR)
 * @param array $context Contexte supplémentaire (variables, stack trace, etc.)
 */
function logMessage($message, $level = LOG_LEVEL_INFO, $context = []) {
    if ($level < LOG_LEVEL_MIN) {
        return;
    }

    $logDir = dirname(LOG_FILE);
    if (!file_exists($logDir)) {
        mkdir($logDir, 0777, true);
    }
    if (!file_exists(LOG_FILE)) {
        touch(LOG_FILE);
        chmod(LOG_FILE, 0666);
    }
    
    $date = date('Y-m-d H:i:s');
    $levelStr = getLevelString($level);
    
    // Formatage du message
    $logLine = sprintf(
        "[%s] [%s] %s",
        $date,
        $levelStr,
        $message
    );

    // Ajout du contexte si présent
    if (!empty($context)) {
        $logLine .= "\nContext: " . json_encode($context, JSON_PRETTY_PRINT);
    }

    // Ajout de la stack trace pour les erreurs
    if ($level >= LOG_LEVEL_ERROR) {
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
        $logLine .= "\nStack Trace:\n";
        foreach ($trace as $i => $t) {
            $logLine .= sprintf(
                "#%d %s:%d - %s%s%s()\n",
                $i,
                isset($t['file']) ? $t['file'] : 'unknown',
                isset($t['line']) ? $t['line'] : 0,
                isset($t['class']) ? $t['class'] : '',
                isset($t['type']) ? $t['type'] : '',
                $t['function']
            );
        }
    }

    $logLine .= "\n";
    file_put_contents(LOG_FILE, $logLine, FILE_APPEND);

    // En cas d'erreur, on stocke aussi dans la session pour l'affichage
    if ($level >= LOG_LEVEL_ERROR) {
        if (!isset($_SESSION['installation_errors'])) {
            $_SESSION['installation_errors'] = [];
        }
        $_SESSION['installation_errors'][] = $message;
    }
}

/**
 * Fonctions helper pour les différents niveaux de log
 */
function logDebug($message, $context = []) {
    logMessage($message, LOG_LEVEL_DEBUG, $context);
}

function logInfo($message, $context = []) {
    logMessage($message, LOG_LEVEL_INFO, $context);
}

function logWarning($message, $context = []) {
    logMessage($message, LOG_LEVEL_WARNING, $context);
}

function logError($message, $context = []) {
    logMessage($message, LOG_LEVEL_ERROR, $context);
}

/**
 * Convertit un niveau de log en chaîne
 */
function getLevelString($level) {
    switch ($level) {
        case LOG_LEVEL_DEBUG:
            return 'DEBUG';
        case LOG_LEVEL_INFO:
            return 'INFO';
        case LOG_LEVEL_WARNING:
            return 'WARNING';
        case LOG_LEVEL_ERROR:
            return 'ERROR';
        default:
            return 'UNKNOWN';
    }
}

/**
 * Récupère les dernières lignes du fichier de log
 */
function getLastLogs($lines = 50) {
    if (!file_exists(LOG_FILE)) {
        return [];
    }

    $logs = [];
    $file = new SplFileObject(LOG_FILE, 'r');
    $file->seek(PHP_INT_MAX);
    $lastLine = $file->key();
    
    $start = max(0, $lastLine - $lines);
    $file->seek($start);
    
    while (!$file->eof()) {
        $logs[] = $file->current();
        $file->next();
    }
    
    return $logs;
}

/**
 * Nettoie les logs d'erreur de la session
 */
function clearSessionErrors() {
    $_SESSION['installation_errors'] = [];
}