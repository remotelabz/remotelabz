<?php
// /remoteLabz-installer/includes/install.php

require_once 'config.php';
require_once 'database.php';
require_once 'logger.php';

// Vérifier que la requête est de type POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération des paramètres depuis le formulaire
    $db_root_password    = $_POST['db_root_password'] ?? "RemoteLabz-2022$";
    $db_name             = $_POST['db_name'] ?? "remotelabz";
    $db_user             = $_POST['db_user'] ?? "user";
    $db_user_password    = $_POST['db_user_password'] ?? "Mysql-Pa33wrd$";

    $rabbitmq_user       = $_POST['rabbitmq_user'] ?? "remotelabz-amqp";
    $rabbitmq_pass       = $_POST['rabbitmq_pass'] ?? "password-amqp";

    $openvpn_passphrase  = $_POST['openvpn_passphrase'] ?? "R3mot3!abz-0penVPN-CA2020";
    $base_network        = $_POST['base_network'] ?? "10.11.0.0";
    $base_network_netmask= $_POST['base_network_netmask'] ?? "255.255.0.0";

    $public_address      = $_POST['public_address'] ?? "";
    $ssh_username        = $_POST['ssh_username'] ?? "remotelabz";
    $ssh_password        = $_POST['ssh_password'] ?? "password";

    $system_email        = $_POST['system_email'] ?? "myemail@domaine.com";
    $jwt_passphrase      = $_POST['jwt_passphrase'] ?? "JWTTok3n";

    $worker_server       = $_POST['worker_server'] ?? "";
    $worker_ssh_username = $_POST['worker_ssh_username'] ?? "remotelabz";
    $worker_ssh_password = $_POST['worker_ssh_password'] ?? "password";
    $worker_ssh_port     = $_POST['worker_ssh_port'] ?? "22";

    $branch              = $_POST['branch'] ?? "master";

    // Génération d'une clé API aléatoire
    $api_key             = bin2hex(random_bytes(16));

    // Vérifier que l'adresse publique n'est pas vide
    if (empty($public_address)) {
        logMessage("Erreur: L'adresse publique du front ne peut pas être vide.");
        $installationSuccess = false;
        $output = "Erreur: L'adresse publique du front ne peut pas être vide.";
    } else {
        // Execution de check_requirements.sh
        logMessage("Vérification des prérequis en cours...");
        $stream = popen('bash ../scripts/check_requirements.sh', 'r');
        $output = stream_get_contents($stream);
        fclose($stream);

        if (strpos($output, 'Erreur') !== false) {
            logMessage("Échec de la vérification des prérequis.");
            $installationSuccess = false;
        } else {
            logMessage("Vérification des prérequis terminée.");
            $installationSuccess = true;
        }
    }

    // Connexion SSH à la machine pour le Front
    $outputFront = "";
    $outputWorker = "";

    if ($installationSuccess) {
        logMessage("Installation du Front en cours...");
        $command = sprintf(
            'bash ../scripts/connect_front.sh %s %s %s %s %s %s %s %s %s %s %s %s',
            escapeshellarg($public_address),
            escapeshellarg($ssh_username),
            escapeshellarg($ssh_password),
            escapeshellarg($api_key),
            escapeshellarg($rabbitmq_user),
            escapeshellarg($rabbitmq_pass),
            escapeshellarg($jwt_passphrase),
            escapeshellarg($branch),
            escapeshellarg($db_root_password),
            escapeshellarg($db_user_password),
            escapeshellarg($openvpn_passphrase),
            escapeshellarg($system_email)
        );
        $stream = popen($command, 'r');
        $outputFront = stream_get_contents($stream);
        $status = pclose($stream);
        
        // Vérifier le code de retour du script
        if ($status != 0 || strpos($outputFront, 'Erreur') !== false) {
            logMessage("Échec de l'installation du Front. Code de retour: " . $status);
            $installationSuccess = false;
        } else {
            logMessage("Installation du Front terminée.");
        }
    }

    // Connexion SSH à la machine pour le Worker
    if ($installationSuccess && !empty($worker_server)) {
        logMessage("Installation du Worker en cours...");
        
        // Préparer les configurations pour le worker
        $workerConfig = [
            'server' => $worker_server,
            'branch' => $branch,
            'ssh_username' => $worker_ssh_username,
            'ssh_password' => $worker_ssh_password,
            'ssh_port' => $worker_ssh_port
        ];
        
        $systemConfig = [
            'email' => $system_email
        ];
        
        $scriptPath = '../scripts/connect_worker.sh';
        
        $status = installWorker($workerConfig, $systemConfig, $scriptPath, $public_address);
        
        if ($status != 0) {
            logMessage("Échec de l'installation du Worker. Code de retour: " . $status);
            $installationSuccess = false;
        } else {
            logMessage("Installation du Worker terminée.");
        }
    }

    // Stocker les résultats pour l'affichage
    $_SESSION['installation_results'] = [
        'success' => $installationSuccess,
        'output_front' => $outputFront,
        'output_worker' => $outputWorker
    ];

    // Rediriger vers la page de résultats
    header('Location: ../install_result.php');
    exit;
}
// Si la méthode n'est pas POST, laissez le script continuer pour l'affichage du formulaire
// Ne rien faire ici pour permettre l'accès à la page d'installation

function connectWorker($workerConfig, $systemConfig, $scriptPath, $frontPublicAddress) {
    // Cette fonction est maintenue pour la compatibilité mais n'est plus utilisée
    // Utiliser installWorker à la place
    return installWorker($workerConfig, $systemConfig, $scriptPath, $frontPublicAddress);
}

function installWorker($workerConfig, $systemConfig, $scriptPath, $frontPublicAddress = null) {
    // S'assurer que la branche est définie, utiliser 'master' par défaut si non spécifiée
    if (!isset($workerConfig['branch']) || empty($workerConfig['branch'])) {
        $workerConfig['branch'] = 'master';
        logWarning("Branche du worker non spécifiée, utilisation de 'master' par défaut");
    }
    
    // S'assurer que le nom d'utilisateur SSH est défini
    if (!isset($workerConfig['ssh_username']) || empty($workerConfig['ssh_username'])) {
        $workerConfig['ssh_username'] = 'remotelabz';
        logWarning("Nom d'utilisateur SSH non spécifié, utilisation de 'remotelabz' par défaut");
    }
    
    // Si frontPublicAddress n'est pas fourni, utiliser l'adresse du serveur worker
    if ($frontPublicAddress === null) {
        $frontPublicAddress = $workerConfig['server'];
    }
    
    logDebug("Installation Worker distant", ['worker' => $workerConfig, 'system' => $systemConfig]);
    $command = sprintf(
        'bash %s "%s" "%s" "%s" "%s" "%s" "%s" "%s" 2>&1',
        escapeshellarg($scriptPath),
        escapeshellarg($workerConfig['server']),        // <worker_server>
        escapeshellarg($workerConfig['branch']),        // <branch> - Utiliser la branche du worker
        escapeshellarg($workerConfig['ssh_password']),  // <ssh_password> - Mot de passe SSH pour la connexion
        escapeshellarg($frontPublicAddress),            // <public_address> - Adresse du front
        escapeshellarg($systemConfig['email']),         // <system_email>
        escapeshellarg($workerConfig['ssh_username']),  // <ssh_username>
        escapeshellarg($workerConfig['ssh_port'])       // <ssh_port>
    );
    
    $output = [];
    $returnCode = 0;
    exec($command, $output, $returnCode);
    
    $outputText = implode("\n", $output);
    logDebug("Sortie installation Worker distant", ['output' => $outputText, 'returnCode' => $returnCode]);
    
    // Stocker la sortie pour l'affichage
    global $outputWorker;
    $outputWorker = $outputText;
    
    return $returnCode;
}