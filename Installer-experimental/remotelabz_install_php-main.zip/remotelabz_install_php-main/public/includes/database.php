<!-- # Script de création et configuration de la base de données --><?php
// /remoteLabz-installer/includes/database.php
require_once 'config.php';
require_once 'logger.php';

function dbConnect($host, $user, $pass, $dbname) {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    try {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        logMessage("Erreur de connexion DB: " . $e->getMessage());
        return false;
    }
}

function dbInitialize($pdo) {
    try {
        // Exemple : création d'une table 'users' (adapter selon les besoins de RemoteLabz)
        $sql = "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL,
            password VARCHAR(255) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        $pdo->exec($sql);
        logMessage("Base de données initialisée avec succès.");
    } catch (PDOException $e) {
        logMessage("Erreur d'initialisation DB: " . $e->getMessage());
    }
}
?>
