<?php
/**
 * Helper functions to interact with GitHub repositories
 */

// Inclure le logger s'il existe
if (file_exists(__DIR__ . '/logger.php')) {
    require_once __DIR__ . '/logger.php';
}

/**
 * Récupère les branches disponibles d'un dépôt GitHub
 * 
 * @param string $repo Le nom du dépôt (ex: 'remotelabz/remotelabz')
 * @return array Un tableau des branches disponibles
 */
function getGitHubBranches($repo) {
    $branches = [];
    $url = "https://api.github.com/repos/{$repo}/branches";
    
    // Journaliser la tentative de récupération des branches
    if (function_exists('logDebug')) {
        logDebug("Tentative de récupération des branches pour le dépôt {$repo}", ['url' => $url]);
    }
    
    // Configuration de la requête
    $options = [
        'http' => [
            'method' => 'GET',
            'header' => [
                'User-Agent: RemoteLabz-Installer',
            ],
            'timeout' => 10,
        ]
    ];
    
    $context = stream_context_create($options);
    
    // Tentative de récupération des branches
    try {
        $response = @file_get_contents($url, false, $context);
        
        if ($response !== false) {
            $data = json_decode($response, true);
            
            if (is_array($data)) {
                foreach ($data as $branch) {
                    if (isset($branch['name'])) {
                        $branches[] = $branch['name'];
                    }
                }
                
                if (function_exists('logDebug')) {
                    logDebug("Branches récupérées avec succès pour {$repo}", ['branches' => $branches]);
                }
            } else {
                if (function_exists('logWarning')) {
                    logWarning("Format de réponse GitHub invalide pour {$repo}");
                }
            }
        } else {
            // Récupérer les détails de l'erreur HTTP
            $error = error_get_last();
            if (function_exists('logWarning')) {
                logWarning("Échec de la récupération des branches GitHub pour {$repo}", ['error' => $error]);
            }
        }
    } catch (Exception $e) {
        // En cas d'erreur, on journalise et on retourne un tableau par défaut
        if (function_exists('logError')) {
            logError("Erreur lors de la récupération des branches GitHub: " . $e->getMessage());
        } else {
            error_log("Erreur lors de la récupération des branches GitHub: " . $e->getMessage());
        }
    }
    
    // Si aucune branche n'a été récupérée, on retourne les branches par défaut
    if (empty($branches)) {
        $branches = ['master', 'dev'];
        
        // Essayer une méthode alternative pour récupérer les branches
        $alternativeBranches = getGitHubBranchesAlternative($repo);
        if (!empty($alternativeBranches)) {
            $branches = $alternativeBranches;
        }
        
        if (function_exists('logInfo')) {
            logInfo("Utilisation des branches par défaut ou alternatives pour {$repo}", ['branches' => $branches]);
        }
    }
    
    return $branches;
}

/**
 * Méthode alternative pour récupérer les branches d'un dépôt GitHub
 * en utilisant la commande git ls-remote
 * 
 * @param string $repo Le nom du dépôt
 * @return array Un tableau des branches disponibles
 */
function getGitHubBranchesAlternative($repo) {
    $branches = [];
    $repoUrl = "https://github.com/{$repo}.git";
    
    // Exécuter la commande git ls-remote
    $command = "git ls-remote --heads {$repoUrl}";
    exec($command, $output, $returnCode);
    
    if ($returnCode === 0 && !empty($output)) {
        foreach ($output as $line) {
            if (preg_match('#refs/heads/(.+)$#', $line, $matches)) {
                $branches[] = $matches[1];
            }
        }
        
        if (function_exists('logDebug')) {
            logDebug("Branches récupérées avec la méthode alternative pour {$repo}", ['branches' => $branches]);
        }
    } else {
        if (function_exists('logWarning')) {
            logWarning("Échec de la méthode alternative pour récupérer les branches de {$repo}", [
                'command' => $command,
                'returnCode' => $returnCode
            ]);
        }
    }
    
    return $branches;
}

/**
 * Génère les options HTML pour un select avec les branches GitHub
 * 
 * @param string $repo Le nom du dépôt
 * @param string $selectedBranch La branche sélectionnée par défaut
 * @return string Le HTML des options
 */
function generateBranchOptions($repo, $selectedBranch = 'dev') {
    $branches = getGitHubBranches($repo);
    $options = '';
    
    // S'assurer que les branches master et dev sont toujours présentes
    if (!in_array('master', $branches)) {
        $branches[] = 'master';
    }
    if (!in_array('dev', $branches)) {
        $branches[] = 'dev';
    }
    
    // Trier les branches pour mettre master et dev en premier
    usort($branches, function($a, $b) {
        if ($a === 'master') return -1;
        if ($b === 'master') return 1;
        if ($a === 'dev') return -1;
        if ($b === 'dev') return 1;
        return strcmp($a, $b);
    });
    
    foreach ($branches as $branch) {
        $selected = ($branch === $selectedBranch) ? 'selected' : '';
        $label = $branch;
        
        // Ajouter des labels spécifiques pour les branches communes
        if ($branch === 'master') {
            $label .= ' (stable)';
        } elseif ($branch === 'dev') {
            $label .= ' (développement)';
        }
        
        $options .= "<option value=\"{$branch}\" {$selected}>{$label}</option>\n";
    }
    
    return $options;
}
