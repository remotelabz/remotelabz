<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['openvpn_config'] = [
        'passphrase' => $_POST['openvpn_passphrase'],
        'base_network' => $_POST['base_network'],
        'base_network_netmask' => $_POST['base_network_netmask']
    ];
    header('Location: ?step=' . ($currentStep + 1));
    exit;
}
?>

<h1>Configuration d'OpenVPN</h1>

<form method="post" class="config-form">
    <div class="form-group">
        <label for="openvpn_passphrase">Passphrase pour la clé OpenVPN :</label>
        <input type="text" id="openvpn_passphrase" name="openvpn_passphrase" 
               value="<?php echo isset($_SESSION['openvpn_config']['passphrase']) ? $_SESSION['openvpn_config']['passphrase'] : 'R3mot3!abz-0penVPN-CA2020'; ?>" 
               required>
        <p class="help-text">Cette passphrase sera utilisée pour générer les clés OpenVPN</p>
    </div>

    <div class="form-group">
        <label for="base_network">Réseau de base (BASE_NETWORK) :</label>
        <input type="text" id="base_network" name="base_network" 
               value="<?php echo isset($_SESSION['openvpn_config']['base_network']) ? $_SESSION['openvpn_config']['base_network'] : '10.11.0.0'; ?>" 
               pattern="^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$"
               required>
        <p class="help-text">Format: xxx.xxx.xxx.xxx (ex: 10.11.0.0)</p>
    </div>

    <div class="form-group">
        <label for="base_network_netmask">Masque réseau (BASE_NETWORK_NETMASK) :</label>
        <input type="text" id="base_network_netmask" name="base_network_netmask" 
               value="<?php echo isset($_SESSION['openvpn_config']['base_network_netmask']) ? $_SESSION['openvpn_config']['base_network_netmask'] : '255.255.0.0'; ?>" 
               pattern="^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$"
               required>
        <p class="help-text">Format: xxx.xxx.xxx.xxx (ex: 255.255.0.0)</p>
    </div>

    <div class="warning-box">
        <p>⚠️ Attention : Le réseau spécifié sera utilisé pour vos laboratoires. Assurez-vous qu'il soit différent de votre réseau local.</p>
    </div>

    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" class="button primary">Suivant</button>
    </div>
</form>
