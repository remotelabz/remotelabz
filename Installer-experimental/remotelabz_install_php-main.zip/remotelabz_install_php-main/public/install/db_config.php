<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['db_config'] = [
        'root_password' => $_POST['db_root_password'],
        'name' => $_POST['db_name'],
        'user' => $_POST['db_user'],
        'user_password' => $_POST['db_user_password']
    ];
    header('Location: ?step=' . ($currentStep + 1));
    exit;
}
?>

<h1>Configuration de la base de données MySQL</h1>

<form method="post" class="config-form">
    <div class="form-group">
        <label for="db_root_password">Mot de passe root MySQL :</label>
        <div class="password-container">
            <input type="password" id="db_root_password" name="db_root_password" 
                   value="<?php echo isset($_SESSION['db_config']['root_password']) ? $_SESSION['db_config']['root_password'] : 'RemoteLabz-2022$'; ?>" 
                   required>
            <span class="toggle-password" onclick="togglePasswordVisibility('db_root_password')">👁</span>
        </div>
    </div>

    <div class="form-group">
        <label for="db_name">Nom de la base de données :</label>
        <input type="text" id="db_name" name="db_name" 
               value="<?php echo isset($_SESSION['db_config']['name']) ? $_SESSION['db_config']['name'] : 'remotelabz'; ?>" 
               required>
    </div>

    <div class="form-group">
        <label for="db_user">Utilisateur de la base :</label>
        <input type="text" id="db_user" name="db_user" 
               value="<?php echo isset($_SESSION['db_config']['user']) ? $_SESSION['db_config']['user'] : 'user'; ?>" 
               required>
    </div>

    <div class="form-group">
        <label for="db_user_password">Mot de passe de l'utilisateur :</label>
        <div class="password-container">
            <input type="password" id="db_user_password" name="db_user_password" 
                   value="<?php echo isset($_SESSION['db_config']['user_password']) ? $_SESSION['db_config']['user_password'] : 'Mysql-Pa33wrd$'; ?>" 
                   required>
            <span class="toggle-password" onclick="togglePasswordVisibility('db_user_password')">👁</span>
        </div>
    </div>

    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" class="button primary">Suivant</button>
    </div>
</form>

<script>
function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
