<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['rabbitmq_config'] = [
        'user' => $_POST['rabbitmq_user'],
        'password' => $_POST['rabbitmq_pass']
    ];
    header('Location: ?step=' . ($currentStep + 1));
    exit;
}
?>

<h1>Configuration de RabbitMQ</h1>

<div class="info-box">
    <p>RabbitMQ est utilisé pour la communication entre le Front et les Workers. Il est essentiel pour le bon fonctionnement de RemoteLabz.</p>
</div>

<form method="post" class="config-form">
    <div class="form-group">
        <label for="rabbitmq_user">Utilisateur RabbitMQ :</label>
        <input type="text" id="rabbitmq_user" name="rabbitmq_user" 
               value="<?php echo isset($_SESSION['rabbitmq_config']['user']) ? $_SESSION['rabbitmq_config']['user'] : 'remotelabz-amqp'; ?>" 
               required>
    </div>

    <div class="form-group">
        <label for="rabbitmq_pass">Mot de passe RabbitMQ :</label>
        <div class="password-container">
            <input type="password" id="rabbitmq_pass" name="rabbitmq_pass" 
                   value="<?php echo isset($_SESSION['rabbitmq_config']['password']) ? $_SESSION['rabbitmq_config']['password'] : 'password-amqp'; ?>" 
                   required>
            <span class="toggle-password" onclick="togglePasswordVisibility('rabbitmq_pass')">👁</span>
        </div>
        <p class="help-text">Ce mot de passe sera utilisé pour l'authentification entre le Front et les Workers</p>
    </div>

    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" class="button primary">Suivant</button>
    </div>
</form>

<script>
function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
