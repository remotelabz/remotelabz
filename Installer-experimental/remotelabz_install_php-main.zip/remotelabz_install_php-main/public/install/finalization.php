<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération de toutes les configurations
    $config = [
        'db' => $_SESSION['db_config'],
        'openvpn' => $_SESSION['openvpn_config'],
        'dhcp' => $_SESSION['dhcp_config'] ?? ['enabled' => false],
        'rabbitmq' => $_SESSION['rabbitmq_config'],
        'exim4' => $_SESSION['exim4_config'],
        'jwt' => $_SESSION['jwt_config'],
        'front' => $_SESSION['front_config'],
        'worker' => $_SESSION['worker_config']
    ];

    // Sauvegarde de la configuration
    file_put_contents(__DIR__ . '/../config/install.json', json_encode($config, JSON_PRETTY_PRINT));

    // Redirection vers la page de progression
    header('Location: /install_progress.php');
    exit;
}
?>

<h1>Finalisation de l'installation</h1>

<div class="summary-container">
    <h2>Récapitulatif de la configuration</h2>
    
    <div class="summary-section">
        <h3>Base de données</h3>
        <ul>
            <li>Nom de la base : <?php echo $_SESSION['db_config']['name']; ?></li>
            <li>Utilisateur : <?php echo $_SESSION['db_config']['user']; ?></li>
        </ul>
    </div>

    <div class="summary-section">
        <h3>OpenVPN</h3>
        <ul>
            <li>Réseau : <?php echo $_SESSION['openvpn_config']['base_network']; ?></li>
            <li>Masque : <?php echo $_SESSION['openvpn_config']['base_network_netmask']; ?></li>
        </ul>
    </div>

    <div class="summary-section">
        <h3>Service DHCP</h3>
        <?php if (isset($_SESSION['dhcp_config']) && $_SESSION['dhcp_config']['enabled']): ?>
        <ul>
            <li>Statut : <span class="success-text">Activé</span></li>
            <li>Attribution automatique des IP : <?php echo $_SESSION['dhcp_config']['automatic_ip'] === 'yes' ? 'Oui' : 'Non'; ?></li>
            <li>Réseau de base : <?php echo $_SESSION['dhcp_config']['base_network']; ?></li>
            <li>Masque (CIDR) : /<?php echo $_SESSION['dhcp_config']['netmask']; ?></li>
            <li>Suffixe de la passerelle : <?php echo $_SESSION['dhcp_config']['gateway_suffix']; ?></li>
        </ul>
        <?php else: ?>
        <ul>
            <li>Statut : <span class="warning-text">Désactivé</span></li>
            <li>Note : Les utilisateurs devront configurer manuellement les adresses IP de leurs machines</li>
        </ul>
        <?php endif; ?>
    </div>

    <div class="summary-section">
        <h3>RabbitMQ</h3>
        <ul>
            <li>Utilisateur : <?php echo $_SESSION['rabbitmq_config']['user']; ?></li>
        </ul>
    </div>

    <div class="summary-section">
        <h3>Service de messagerie</h3>
        <ul>
            <li>Email système : <?php echo $_SESSION['exim4_config']['system_email']; ?></li>
        </ul>
    </div>

    <div class="summary-section">
        <h3>Front</h3>
        <ul>
            <li>Adresse publique : <?php echo $_SESSION['front_config']['public_address']; ?></li>
            <li>Version : <?php echo $_SESSION['front_config']['branch']; ?></li>
            <li>Utilisateur SSH : <?php echo $_SESSION['front_config']['ssh_username']; ?></li>
            <li>Port SSH : <?php echo $_SESSION['front_config']['ssh_port']; ?></li>
        </ul>
    </div>

    <div class="summary-section">
        <h3>Worker</h3>
        <ul>
            <li>Serveur : <?php echo $_SESSION['worker_config']['server']; ?></li>
            <li>Utilisateur SSH : <?php echo $_SESSION['worker_config']['ssh_username']; ?></li>
            <li>Port SSH : <?php echo $_SESSION['worker_config']['ssh_port']; ?></li>
            <li>Installation : <?php echo $_SESSION['worker_config']['same_machine'] === 'yes' ? 'Sur la même machine que le Front' : 'Sur une machine distincte'; ?></li>
        </ul>
    </div>
</div>

<div class="warning-box">
    <p>⚠️ L'installation peut prendre plusieurs minutes. Ne fermez pas votre navigateur pendant le processus.</p>
</div>

<?php if (isset($_SESSION['dhcp_config']) && $_SESSION['dhcp_config']['enabled']): ?>
<div class="info-box">
    <h3>🔧 Configuration du conteneur Service DHCP</h3>
    <p>Après l'installation, n'oubliez pas de configurer le conteneur "Service" qui fournira le service DHCP à vos laboratoires :</p>
    <ol>
        <li>Démarrez le conteneur "Migration" via le menu Sandbox</li>
        <li>Exécutez le script fourni pour configurer automatiquement le service DHCP</li>
        <li>Exportez le conteneur sous le nom "Service"</li>
    </ol>
    <p>Un script de configuration vous sera fourni à la fin de l'installation.</p>
</div>
<?php endif; ?>

<form method="post" class="config-form">
    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" name="start_install" class="button primary">Lancer l'installation</button>
    </div>
</form>
