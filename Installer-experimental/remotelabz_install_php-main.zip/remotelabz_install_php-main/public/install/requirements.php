<?php
$requirements = [
    'php_version' => ['required' => '7.4', 'current' => PHP_VERSION],
    'extensions' => [
        'pdo_mysql',
        'openssl',
        'json',
        'curl',
        'mbstring',
        'xml'
    ],
    'commands' => [
        'git' => 'git --version',
        'composer' => 'composer --version'
    ]
];

function checkCommand($command) {
    exec("which " . explode(' ', $command)[0], $output, $return);
    return $return === 0;
}
?>

<h1>Vérification des prérequis</h1>

<div class="requirements-check">
    <h2>Version PHP</h2>
    <div class="requirement-item <?php echo version_compare(PHP_VERSION, $requirements['php_version']['required'], '>=') ? 'success' : 'error'; ?>">
        Version requise : <?php echo $requirements['php_version']['required']; ?><br>
        Version actuelle : <?php echo $requirements['php_version']['current']; ?>
    </div>

    <h2>Extensions PHP</h2>
    <?php foreach ($requirements['extensions'] as $ext): ?>
    <div class="requirement-item <?php echo extension_loaded($ext) ? 'success' : 'error'; ?>">
        <?php echo $ext; ?>: <?php echo extension_loaded($ext) ? 'Installée' : 'Non installée'; ?>
    </div>
    <?php endforeach; ?>

    <h2>Commandes requises</h2>
    <?php foreach ($requirements['commands'] as $name => $command): ?>
    <div class="requirement-item <?php echo checkCommand($command) ? 'success' : 'error'; ?>">
        <?php echo $name; ?>: <?php echo checkCommand($command) ? 'Installé' : 'Non installé'; ?>
    </div>
    <?php endforeach; ?>
</div>

<div class="navigation-buttons">
    <a href="?step=<?php echo $currentStep + 1; ?>" class="button primary">Suivant</a>
</div>
