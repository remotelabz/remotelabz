<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['jwt_config'] = [
        'passphrase' => $_POST['jwt_passphrase']
    ];
    header('Location: ?step=' . ($currentStep + 1));
    exit;
}
?>

<h1>Configuration des clés API (JWT)</h1>

<div class="info-box">
    <p>Les clés JWT (JSON Web Token) sont utilisées pour sécuriser l'API de RemoteLabz.</p>
</div>

<form method="post" class="config-form">
    <div class="form-group">
        <label for="jwt_passphrase">Passphrase JWT :</label>
        <div class="password-container">
            <input type="password" id="jwt_passphrase" name="jwt_passphrase" 
                   value="<?php echo isset($_SESSION['jwt_config']['passphrase']) ? $_SESSION['jwt_config']['passphrase'] : 'JWTTok3n'; ?>" 
                   required>
            <span class="toggle-password" onclick="togglePasswordVisibility('jwt_passphrase')">👁</span>
        </div>
        <p class="help-text">Cette passphrase sera utilisée pour générer les clés JWT</p>
    </div>

    <div class="info-box">
        <h3>Génération automatique des clés</h3>
        <p>Les actions suivantes seront effectuées automatiquement :</p>
        <ul>
            <li>Création du répertoire config/jwt</li>
            <li>Génération de la clé privée (private.pem)</li>
            <li>Génération de la clé publique (public.pem)</li>
        </ul>
    </div>

    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" class="button primary">Suivant</button>
    </div>
</form>

<script>
function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
