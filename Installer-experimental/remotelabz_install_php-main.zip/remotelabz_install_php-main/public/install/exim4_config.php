<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['exim4_config'] = [
        'system_email' => $_POST['system_email']
    ];
    header('Location: ?step=' . ($currentStep + 1));
    exit;
}
?>

<h1>Configuration du service de messagerie (Exim4)</h1>

<div class="info-box">
    <p>Exim4 est utilisé pour l'envoi des emails système et des notifications aux utilisateurs.</p>
</div>

<form method="post" class="config-form">
    <div class="form-group">
        <label for="system_email">Adresse email pour la redirection des mails système :</label>
        <input type="email" id="system_email" name="system_email" 
               value="<?php echo isset($_SESSION['exim4_config']['system_email']) ? $_SESSION['exim4_config']['system_email'] : 'myemail@domaine.com'; ?>" 
               required>
        <p class="help-text">Tous les emails système seront redirigés vers cette adresse</p>
    </div>

    <div class="info-box">
        <h3>Configuration automatique</h3>
        <p>Les actions suivantes seront effectuées automatiquement :</p>
        <ul>
            <li>Configuration du fichier /etc/aliases</li>
            <li>Mise à jour de la configuration d'Exim4</li>
            <li>Redémarrage du service Exim4</li>
        </ul>
    </div>

    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" class="button primary">Suivant</button>
    </div>
</form>
