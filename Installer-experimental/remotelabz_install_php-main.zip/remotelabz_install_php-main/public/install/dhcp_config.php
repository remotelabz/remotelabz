<?php
// /remoteLabz-installer/install/dhcp_config.php

// Si le formulaire a été soumis, traiter les données
if (isset($_POST['submit_dhcp'])) {
    $_SESSION['dhcp_configured'] = true;
    
    // Récupérer les données du formulaire
    $dhcp_enabled = isset($_POST['dhcp_enabled']) ? $_POST['dhcp_enabled'] : 'no';
    
    if ($dhcp_enabled === 'yes') {
        $_SESSION['dhcp_enabled'] = true;
        
        // Stocker les préférences dans la session
        $_SESSION['dhcp_config'] = [
            'enabled' => true,
            'automatic_ip' => isset($_POST['automatic_ip']) ? $_POST['automatic_ip'] : 'yes',
            'base_network' => isset($_POST['base_network']) ? $_POST['base_network'] : '10.10.10.0',
            'netmask' => isset($_POST['netmask']) ? $_POST['netmask'] : '27',
            'gateway_suffix' => isset($_POST['gateway_suffix']) ? $_POST['gateway_suffix'] : '30'
        ];
        
        // Afficher le message de succès
        echo '<div class="success">Configuration DHCP enregistrée avec succès!</div>';
    } else {
        $_SESSION['dhcp_enabled'] = false;
        $_SESSION['dhcp_config'] = [
            'enabled' => false
        ];
        
        // Afficher le message de succès
        echo '<div class="success">Service DHCP désactivé. Vous devrez configurer manuellement les adresses IP de vos machines.</div>';
    }
    
    // Passer à l'étape suivante
    echo '<script>setTimeout(function(){ window.location.href="?step=' . ($currentStep + 1) . '"; }, 2000);</script>';
}

// Récupérer les valeurs précédemment enregistrées
$dhcp_config = $_SESSION['dhcp_config'] ?? [
    'enabled' => false,
    'automatic_ip' => 'yes',
    'base_network' => '10.10.10.0',
    'netmask' => '27',
    'gateway_suffix' => '30'
];

$dhcp_enabled = $dhcp_config['enabled'] ? 'yes' : 'no';
?>

<h2>Configuration du service DHCP</h2>

<div class="info-box">
    <h3>À propos du service DHCP</h3>
    <p>RemoteLabz permet d'ajouter un service DHCP à chaque laboratoire. Ce service est fourni par un conteneur spécial appelé "Service" qui est configuré automatiquement en fonction du réseau attribué à votre laboratoire.</p>
    <p>Lorsque vous ajoutez le conteneur "Service" à un laboratoire :</p>
    <ul>
        <li>Il se configure automatiquement avec l'adresse IP : <strong>IP_Passerelle - 1</strong></li>
        <li>Exemple : si votre réseau est 10.10.10.0/27, la passerelle sera 10.10.10.30 et le conteneur DHCP aura l'IP 10.10.10.29</li>
    </ul>
</div>

<form method="POST" action="">
    <div class="form-group">
        <label for="dhcp_enabled">Activer le service DHCP :</label>
        <select id="dhcp_enabled" name="dhcp_enabled" class="form-control" onchange="toggleDhcpOptions(this.value)">
            <option value="yes" <?php echo $dhcp_enabled === 'yes' ? 'selected' : ''; ?>>Oui</option>
            <option value="no" <?php echo $dhcp_enabled === 'no' ? 'selected' : ''; ?>>Non</option>
        </select>
        <small>Si activé, les laboratoires pourront utiliser le conteneur "Service" pour fournir un service DHCP.</small>
    </div>
    
    <div id="dhcp_options" style="<?php echo $dhcp_enabled === 'no' ? 'display:none;' : ''; ?>">
        <div class="form-group">
            <label for="automatic_ip">Attribution automatique des IP :</label>
            <select id="automatic_ip" name="automatic_ip" class="form-control">
                <option value="yes" <?php echo $dhcp_config['automatic_ip'] === 'yes' ? 'selected' : ''; ?>>Oui</option>
                <option value="no" <?php echo $dhcp_config['automatic_ip'] === 'no' ? 'selected' : ''; ?>>Non</option>
            </select>
            <small>Si désactivé, les utilisateurs devront configurer manuellement les IP dans leurs laboratoires.</small>
        </div>
        
        <div class="form-group">
            <label for="base_network">Réseau de base :</label>
            <input type="text" id="base_network" name="base_network" class="form-control" value="<?php echo $dhcp_config['base_network']; ?>" pattern="\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}" required>
            <small>Exemple : 10.10.10.0</small>
        </div>
        
        <div class="form-group">
            <label for="netmask">Masque de sous-réseau (CIDR) :</label>
            <input type="number" id="netmask" name="netmask" class="form-control" value="<?php echo $dhcp_config['netmask']; ?>" min="16" max="30" required>
            <small>Exemple : 27 (correspond à 255.255.255.224)</small>
        </div>
        
        <div class="form-group">
            <label for="gateway_suffix">Suffixe de la passerelle :</label>
            <input type="number" id="gateway_suffix" name="gateway_suffix" class="form-control" value="<?php echo $dhcp_config['gateway_suffix']; ?>" min="1" max="254" required>
            <small>Par défaut : 30. La passerelle sera l'adresse IP avec ce suffixe, et le serveur DHCP sera l'adresse IP avec le suffixe (gateway_suffix - 1).</small>
        </div>
    </div>
    
    <div class="form-actions">
        <button type="submit" name="submit_dhcp" class="btn-primary">Enregistrer</button>
    </div>
</form>

<div class="info-box code-example">
    <h3>Comment configurer manuellement le conteneur Service</h3>
    <p>Instructions pour configurer manuellement le service DHCP :</p>
    <ol>
        <li>Démarrer le conteneur "Migration" via le menu Sandbox</li>
        <li>Dans la console, configurer le réseau du périphérique :</li>
        <li><code>ip addr add X.X.X.X/M dev eth0</code> (ajouter une adresse IP)</li>
        <li><code>ip route add default via X.X.X.X</code> (ajouter la route par défaut)</li>
        <li>Exécuter les commandes suivantes pour installer et configurer le service DHCP :</li>
    </ol>
    <pre><code>sudo rm /etc/resolv.conf
echo "nameserver 1.1.1.1" > /etc/resolv.conf
apt-get update; apt-get -y upgrade; apt-get install -y dnsmasq;
echo "dhcp-range=RANGE_TO_DEFINED" >> /etc/dnsmasq.conf
echo "dhcp-option=3,GW_TO_DEFINED" >> /etc/dnsmasq.conf
systemctl stop systemd-resolved
systemctl disable systemd-resolved
systemctl disable systemd-networkd
systemctl enable dnsmasq</code></pre>
    <p>Après avoir configuré le conteneur, arrêtez-le, cliquez sur Exporter et choisissez "Service" comme nouveau nom.</p>
</div>

<script>
function toggleDhcpOptions(value) {
    const dhcpOptions = document.getElementById('dhcp_options');
    if (value === 'yes') {
        dhcpOptions.style.display = 'block';
    } else {
        dhcpOptions.style.display = 'none';
    }
}
</script> 