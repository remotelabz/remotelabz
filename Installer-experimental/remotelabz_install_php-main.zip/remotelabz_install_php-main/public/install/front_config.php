<?php
require_once __DIR__ . '/../includes/github_helper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['front_config'] = [
        'public_address' => $_POST['public_address'],
        'ssh_username' => $_POST['ssh_username'],
        'ssh_password' => $_POST['ssh_password'],
        'ssh_port' => $_POST['ssh_port'],
        'branch' => $_POST['branch']
    ];
    header('Location: ?step=' . ($currentStep + 1));
    exit;
}

// Définir la branche par défaut
$defaultBranch = isset($_SESSION['front_config']['branch']) ? $_SESSION['front_config']['branch'] : 'dev';
?>

<h1>Configuration du Front</h1>

<form method="post" class="config-form">
    <div class="form-group">
        <label for="public_address">Adresse publique du Front :</label>
        <input type="text" id="public_address" name="public_address" 
               value="<?php echo isset($_SESSION['front_config']['public_address']) ? $_SESSION['front_config']['public_address'] : ''; ?>" 
               placeholder="votredomaine.com"
               required>
        <p class="help-text">L'adresse publique qui sera utilisée pour accéder à RemoteLabz</p>
    </div>

    <div class="form-group">
        <label for="ssh_username">Nom d'utilisateur SSH :</label>
        <input type="text" id="ssh_username" name="ssh_username" 
               value="<?php echo isset($_SESSION['front_config']['ssh_username']) ? $_SESSION['front_config']['ssh_username'] : 'remotelabz'; ?>" 
               required>
    </div>

    <div class="form-group">
        <label for="ssh_port">Port SSH :</label>
        <input type="number" id="ssh_port" name="ssh_port" 
               value="<?php echo isset($_SESSION['front_config']['ssh_port']) ? $_SESSION['front_config']['ssh_port'] : '22'; ?>" 
               required
               min="1"
               max="65535">
        <p class="help-text">Le port SSH utilisé pour la connexion (par défaut: 22)</p>
    </div>

    <div class="form-group">
        <label for="ssh_password">Mot de passe SSH :</label>
        <div class="password-container">
            <input type="password" id="ssh_password" name="ssh_password" 
                   value="<?php echo isset($_SESSION['front_config']['ssh_password']) ? $_SESSION['front_config']['ssh_password'] : 'password'; ?>" 
                   required>
            <span class="toggle-password" onclick="togglePasswordVisibility('ssh_password')">👁</span>
        </div>
    </div>

    <div class="form-group">
        <label for="branch">Version à installer :</label>
        <select id="branch" name="branch" required>
            <?php echo generateBranchOptions('remotelabz/remotelabz', $defaultBranch); ?>
        </select>
        <p class="help-text">La branche GitHub à utiliser pour l'installation</p>
    </div>

    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" class="button primary">Suivant</button>
    </div>
</form>

<script>
function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
