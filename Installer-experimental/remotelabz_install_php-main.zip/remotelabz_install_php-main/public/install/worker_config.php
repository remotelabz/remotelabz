<?php
require_once __DIR__ . '/../includes/github_helper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['worker_config'] = [
        'server' => $_POST['worker_server'],
        'ssh_username' => $_POST['worker_ssh_username'],
        'ssh_password' => $_POST['worker_ssh_password'],
        'ssh_port' => $_POST['worker_ssh_port'],
        'branch' => $_POST['worker_branch'],
        'same_machine' => $_POST['same_machine']
    ];
    header('Location: ?step=' . ($currentStep + 1));
    exit;
}

// Définir la branche par défaut
$defaultBranch = isset($_SESSION['worker_config']['branch']) ? $_SESSION['worker_config']['branch'] : 'dev';
?>

<h1>Configuration du Worker</h1>

<div class="info-box">
    <p>Le Worker est responsable de l'exécution des machines virtuelles et des conteneurs. Il peut être installé sur la même machine que le Front ou sur une machine différente.</p>
</div>

<form method="post" class="config-form">
    <div class="form-group">
        <label for="same_machine">Installation sur la même machine que le Front :</label>
        <div class="radio-group">
            <div class="radio-option">
                <input type="radio" id="same_machine_yes" name="same_machine" value="yes" 
                       <?php echo (isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes') ? 'checked' : ''; ?> 
                       onchange="toggleWorkerFields()">
                <label for="same_machine_yes">Oui</label>
            </div>
            
            <div class="radio-option">
                <input type="radio" id="same_machine_no" name="same_machine" value="no" 
                       <?php echo (!isset($_SESSION['worker_config']['same_machine']) || $_SESSION['worker_config']['same_machine'] === 'no') ? 'checked' : ''; ?> 
                       onchange="toggleWorkerFields()">
                <label for="same_machine_no">Non</label>
            </div>
        </div>
        <p class="help-text">Si vous choisissez "Oui", le Worker sera installé sur la même machine que le Front (installation standalone)</p>
    </div>

    <div id="worker_remote_fields" class="<?php echo (isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes') ? 'hidden' : ''; ?>">
        <div class="form-group">
            <label for="worker_server">Adresse du serveur Worker :</label>
            <input type="text" id="worker_server" name="worker_server" 
                   value="<?php echo isset($_SESSION['worker_config']['server']) ? $_SESSION['worker_config']['server'] : ''; ?>" 
                   placeholder="123.12.167.22"
                   <?php echo (isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes') ? '' : 'required'; ?>>
            <p class="help-text">L'adresse IP ou le nom d'hôte du serveur qui hébergera le Worker</p>
        </div>

        <div class="form-group">
            <label for="worker_ssh_username">Nom d'utilisateur SSH :</label>
            <input type="text" id="worker_ssh_username" name="worker_ssh_username" 
                   value="<?php echo isset($_SESSION['worker_config']['ssh_username']) ? $_SESSION['worker_config']['ssh_username'] : 'remotelabz'; ?>" 
                   <?php echo (isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes') ? '' : 'required'; ?>>
            <p class="help-text">L'utilisateur SSH qui sera utilisé pour se connecter au Worker</p>
        </div>

        <div class="form-group">
            <label for="worker_ssh_port">Port SSH :</label>
            <input type="number" id="worker_ssh_port" name="worker_ssh_port" 
                   value="<?php echo isset($_SESSION['worker_config']['ssh_port']) ? $_SESSION['worker_config']['ssh_port'] : '22'; ?>" 
                   <?php echo (isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes') ? '' : 'required'; ?>
                   min="1"
                   max="65535">
            <p class="help-text">Le port SSH utilisé pour la connexion (par défaut: 22)</p>
        </div>

        <div class="form-group">
            <label for="worker_ssh_password">Mot de passe SSH :</label>
            <div class="password-container">
                <input type="password" id="worker_ssh_password" name="worker_ssh_password" 
                       value="<?php echo isset($_SESSION['worker_config']['ssh_password']) ? $_SESSION['worker_config']['ssh_password'] : 'password'; ?>" 
                       <?php echo (isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes') ? '' : 'required'; ?>>
                <span class="toggle-password" onclick="togglePasswordVisibility('worker_ssh_password')">👁</span>
            </div>
            <p class="help-text">Le mot de passe SSH de l'utilisateur</p>
        </div>
    </div>

    <div class="form-group">
        <label for="worker_branch">Version du Worker à installer :</label>
        <select id="worker_branch" name="worker_branch" required>
            <?php echo generateBranchOptions('remotelabz/remotelabz-worker', $defaultBranch); ?>
        </select>
        <p class="help-text">La branche GitHub à utiliser pour l'installation du Worker</p>
    </div>

    <div class="warning-box" id="remote_warning" <?php echo (isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes') ? 'style="display:none;"' : ''; ?>>
        <p>⚠️ Assurez-vous que le serveur Worker est accessible via SSH et qu'il dispose des privilèges sudo.</p>
    </div>

    <div class="info-box" id="local_info" <?php echo (!isset($_SESSION['worker_config']['same_machine']) || $_SESSION['worker_config']['same_machine'] === 'no') ? 'style="display:none;"' : ''; ?>>
        <p>ℹ️ L'installation du Worker se fera localement sur la même machine que le Front, conformément à la documentation d'installation standalone.</p>
    </div>

    <div class="navigation-buttons">
        <a href="?step=<?php echo $currentStep - 1; ?>" class="button">Précédent</a>
        <button type="submit" class="button primary">Suivant</button>
    </div>
</form>

<script>
function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}

function toggleWorkerFields() {
    const sameMachine = document.getElementById('same_machine_yes').checked;
    const remoteFields = document.getElementById('worker_remote_fields');
    const remoteWarning = document.getElementById('remote_warning');
    const localInfo = document.getElementById('local_info');
    
    if (sameMachine) {
        remoteFields.classList.add('hidden');
        remoteWarning.style.display = 'none';
        localInfo.style.display = 'block';
        
        // Pré-remplir avec les valeurs du Front
        document.getElementById('worker_server').value = '127.0.0.1';
        document.getElementById('worker_ssh_username').value = '<?php echo isset($_SESSION['front_config']['ssh_username']) ? $_SESSION['front_config']['ssh_username'] : 'remotelabz'; ?>';
        document.getElementById('worker_ssh_password').value = '<?php echo isset($_SESSION['front_config']['ssh_password']) ? $_SESSION['front_config']['ssh_password'] : 'password'; ?>';
        document.getElementById('worker_ssh_port').value = '<?php echo isset($_SESSION['front_config']['ssh_port']) ? $_SESSION['front_config']['ssh_port'] : '22'; ?>';
    } else {
        remoteFields.classList.remove('hidden');
        remoteWarning.style.display = 'block';
        localInfo.style.display = 'none';
    }
}

// Initialiser l'état au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    toggleWorkerFields();
});
</script>

<style>
.hidden {
    display: none;
}
.radio-group {
    display: flex;
    gap: 20px;
    margin-bottom: 10px;
}
.radio-option {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background-color: #2c2c2c;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.2s;
}
.radio-option:hover {
    background-color: #3c3c3c;
}
.radio-option input[type="radio"] {
    margin: 0;
    width: 18px;
    height: 18px;
    accent-color: #BB86FC;
}
.radio-option label {
    margin: 0;
    cursor: pointer;
    color: #e0e0e0;
}
</style>
