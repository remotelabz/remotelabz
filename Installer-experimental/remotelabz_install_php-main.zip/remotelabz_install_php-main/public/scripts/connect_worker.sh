#!/bin/bash
# connect_worker.sh
# Usage: connect_worker.sh <worker_server> <branch> <ssh_password> <public_address> <system_email> <ssh_username> <ssh_port>
# Note: L'ordre des paramètres est important et doit correspondre à l'ordre dans le script install.php

# Activer le mode debogage
set -x

WORKER_SERVER=$1
BRANCH=$2
SSH_PASSWORD=$3
PUBLIC_ADDRESS=$4
SYSTEM_EMAIL=$5
SSH_USERNAME=$6
SSH_PORT=$7

# Créer un fichier de log
LOG_FILE="/tmp/worker_connect.log"
exec > >(tee -a "$LOG_FILE") 2>&1

# Fonction pour afficher les messages d'erreur
error() {
    echo "ERROR: $1" 
    exit 1
}

# Fonction pour afficher les messages de progression
info() {
    echo "INFO: $1"
}

# Afficher les paramètres pour le debogage (sans les mots de passe)
info "Parametres: WORKER_SERVER=$WORKER_SERVER, BRANCH=$BRANCH, PUBLIC_ADDRESS=$PUBLIC_ADDRESS, SYSTEM_EMAIL=$SYSTEM_EMAIL, SSH_USERNAME=$SSH_USERNAME, SSH_PORT=$SSH_PORT"

# Verifier que tous les paramètres sont presents
if [ -z "$WORKER_SERVER" ] || [ -z "$BRANCH" ] || [ -z "$SSH_PASSWORD" ] || [ -z "$PUBLIC_ADDRESS" ] || [ -z "$SYSTEM_EMAIL" ] || [ -z "$SSH_USERNAME" ] || [ -z "$SSH_PORT" ]; then
    error "Tous les parametres sont requis. Usage: connect_worker.sh <worker_server> <branch> <ssh_password> <public_address> <system_email> <ssh_username> <ssh_port>"
fi

# Verifier que le fichier install_worker.sh existe
if [ ! -f "scripts/install_worker.sh" ]; then
    error "Le fichier install_worker.sh n'est pas present. Veuillez verifier le chemin. Voici le chemin actuel : $(pwd)"
fi

# Nettoyer les paramètres
SSH_USERNAME_CLEAN=$(echo $SSH_USERNAME | tr -d "'")
SSH_PASSWORD_CLEAN=$(echo $SSH_PASSWORD | tr -d "'")
WORKER_SERVER_CLEAN=$(echo $WORKER_SERVER | tr -d "'")

# Verifier la connectivite avec le serveur worker
info "Verification de la connectivite avec le serveur worker ($WORKER_SERVER_CLEAN)..."
ping -c 1 -W 5 $WORKER_SERVER_CLEAN > /dev/null
if [ $? -ne 0 ]; then
    error "Impossible de joindre le serveur worker ($WORKER_SERVER_CLEAN). Verifiez l'adresse IP et la connectivite reseau."
fi

# Verifier que sshpass est installe
if ! command -v sshpass &> /dev/null; then
    error "sshpass n'est pas installe. Installez-le avec 'apt-get install sshpass'."
fi

# Test de connexion SSH
info "Test de connexion SSH..."
if ! sshpass -p "$SSH_PASSWORD_CLEAN" ssh -p "$SSH_PORT" -o StrictHostKeyChecking=no "$SSH_USERNAME_CLEAN@$WORKER_SERVER_CLEAN" 'echo "Connexion SSH réussie"'; then
    error "Échec de la connexion SSH. Vérifiez les identifiants et que le serveur SSH est actif."
fi

# Vérifier si NTP est installé sur la machine distante
info "Vérification de la synchronisation temporelle (NTP) sur la machine distante..."
NTP_CHECK=$(sshpass -p "$SSH_PASSWORD_CLEAN" ssh -p "$SSH_PORT" -o StrictHostKeyChecking=no "$SSH_USERNAME_CLEAN@$WORKER_SERVER_CLEAN" 'if ! command -v ntpstat &> /dev/null && ! command -v timedatectl &> /dev/null; then echo "NON"; else echo "OUI"; fi')
if [ "$NTP_CHECK" = "NON" ]; then
    info "ATTENTION: Aucun service de synchronisation temporelle (NTP) détecté sur la machine distante."
    info "Il est fortement recommandé d'installer et configurer NTP pour assurer le bon fonctionnement de RemoteLabz."
fi

# Connexion SSH a la machine Worker et execution du script install_worker.sh
info "Connexion SSH a la machine Worker ($WORKER_SERVER_CLEAN) et execution du script install_worker.sh..."
info "Parametres: WORKER_SERVER=$WORKER_SERVER_CLEAN, BRANCH=$BRANCH, PUBLIC_ADDRESS=$PUBLIC_ADDRESS, SYSTEM_EMAIL=$SYSTEM_EMAIL, SSH_USERNAME=$SSH_USERNAME_CLEAN"

# Afficher le directory courant
info "Current directory: $(pwd)"
# Transmettre les paramètres au script install_worker.sh
sshpass -p "$SSH_PASSWORD_CLEAN" ssh -p "$SSH_PORT" -o StrictHostKeyChecking=no "$SSH_USERNAME_CLEAN@$WORKER_SERVER_CLEAN" 'bash -s' < scripts/install_worker.sh "$WORKER_SERVER_CLEAN" "$BRANCH" "$SSH_PASSWORD_CLEAN" "$PUBLIC_ADDRESS" "$SYSTEM_EMAIL" 2>&1

SSH_EXIT_CODE=${PIPESTATUS[0]}
if [ $SSH_EXIT_CODE -eq 0 ]; then
    info "Connexion SSH a la machine Worker ($WORKER_SERVER_CLEAN) reussie."
    info "N'oubliez pas de configurer le worker dans l'interface web du Front en ajoutant l'IP $WORKER_SERVER_CLEAN"
    exit 0
else
    error "echec de l'execution du script install_worker.sh sur la machine Worker ($WORKER_SERVER_CLEAN). Code de retour: $SSH_EXIT_CODE. Verifiez les logs pour plus de details."
fi