#!/bin/bash
# test_ssh_script.sh
# Script pour tester l'exécution d'un script via SSH

# Récupérer les paramètres depuis le fichier de configuration
WORKER_SERVER="127.0.0.1"
BRANCH="dev"
PUBLIC_ADDRESS="127.0.0.1"
SYSTEM_EMAIL="admin@remotelabz.com"
SSH_USERNAME="remotelabz"
SSH_PASSWORD="password"
SSH_PORT="22"

echo "=== Test d'exécution de script via SSH ==="
echo "Serveur: $WORKER_SERVER"
echo "Utilisateur: $SSH_USERNAME"
echo "===================================="
# Créer un script de test temporaire
TEST_SCRIPT="/tmp/test_remote.sh"
cat > $TEST_SCRIPT << 'EOF'
#!/bin/bash
# Script de test pour installer le worker RemoteLabz
# Usage: test_remote.sh <worker_server> <branch> <ssh_password> <public_address> <ssh_username> <system_email>

set -e

WORKER_SERVER="$1"
BRANCH="$2"
SSH_PASSWORD="$3"
PUBLIC_ADDRESS="$4"
SSH_USERNAME="$5"
SYSTEM_EMAIL="$6"

echo "Serveur: $WORKER_SERVER"
echo "Branch: $BRANCH"
echo "Public Address: $PUBLIC_ADDRESS"
echo "SSH Username: $SSH_USERNAME"
echo "System Email: $SYSTEM_EMAIL"

# Tester l'autorisation sudo
if echo "$SSH_PASSWORD" | sudo -S echo "✅ Autorisation sudo validée" 2>/dev/null; then
    echo "✅ Autorisation sudo validée avec le mot de passe fourni"
else
    echo "⚠️ Échec de l'autorisation sudo avec le mot de passe fourni"
    exit 1
fi

# Étape 1: Récupérer le code source du worker
if [ -d "$HOME/remotelabz-worker" ]; then
    echo "Le répertoire ~/remotelabz-worker existe déjà. Sauvegarde du répertoire..."
    timestamp=$(date +%Y%m%d%H%M%S)
    backup_dir="$HOME/remotelabz-worker-backup-$timestamp"
    mv "$HOME/remotelabz-worker" "$backup_dir"
    echo "Sauvegarde effectuée dans $backup_dir"
fi

cd $HOME
# Ajouter l'option -v (verbose) pour voir plus de détails en cas d'erreur
# Utiliser HTTPS au lieu de SSH pour éviter les problèmes d'authentification
echo "Clonage du dépôt Worker depuis la branche $BRANCH..."
git clone -v https://github.com/remotelabz/remotelabz-worker.git --branch $BRANCH --single-branch

# Étape 2: Installation de l'application RemoteLabz worker
cd $HOME/remotelabz-worker
cp .env .env.local

# Étape 3: Modifier le fichier .env.local selon l'environnement
ADM_INTERFACE=$(ip route | grep default | awk '{print $5}')
sed -i "s/ADM_INTERFACE=.*/ADM_INTERFACE=$ADM_INTERFACE/" .env.local
sed -i "s/FRONT_SERVER_IP=.*/FRONT_SERVER_IP=$PUBLIC_ADDRESS/" .env.local
sed -i "s/CONTACT_MAIL=.*/CONTACT_MAIL=$SYSTEM_EMAIL/" .env.local
sed -i "s/SSH_USER_PASSWD=.*/SSH_USER_PASSWD=$SSH_PASSWORD/" .env.local
sed -i "s#SSH_USER_PRIVATEKEY_FILE=.*#SSH_USER_PRIVATEKEY_FILE=$HOME/.ssh/id_rsa#" .env.local
sed -i "s#SSH_USER_PUBLICKEY_FILE=.*#SSH_USER_PUBLICKEY_FILE=$HOME/.ssh/id_rsa.pub#" .env.local
sed -i "s/REMOTELABZ_PROXY_URL=.*/REMOTELABZ_PROXY_URL=http:\/\/$PUBLIC_ADDRESS/" .env.local
sed -i "s/SYSTEM_EMAIL=.*/SYSTEM_EMAIL=$SYSTEM_EMAIL/" .env.local

# Configuration de Git pour éviter les erreurs d'authentification SSH
echo "Configuration de Git pour utiliser HTTPS..."
git config --global url."https://github.com/".insteadOf git@github.com:
# Désactiver la vérification stricte des clés d'hôte
echo "Désactivation de la vérification stricte des clés d'hôte SSH pour GitHub..."
mkdir -p ~/.ssh
echo "Host github.com
  StrictHostKeyChecking no
  UserKnownHostsFile=/dev/null" > ~/.ssh/config
chmod 600 ~/.ssh/config

# Préalablement accepter la clé GitHub pour éviter les prompts interactifs
echo "Ajout de la clé d'hôte GitHub..."
ssh-keyscan -t rsa github.com >> ~/.ssh/known_hosts 2>/dev/null

echo "Configuration de .env.local terminée. Contenu:"
cat .env.local | grep -v "#" | grep -v "^$" # Afficher uniquement les lignes non vides et non commentées

# Configuration composer pour utiliser HTTPS au lieu de SSH
echo "Configuration de Composer pour utiliser HTTPS..."
echo "$SSH_PASSWORD" | sudo -S mkdir -p /root/.composer
echo "$SSH_PASSWORD" | sudo -S bash -c 'echo "{\"config\": {\"github-protocols\": [\"https\",\"http\"]}}" > /root/.composer/config.json'
echo "$SSH_PASSWORD" | sudo -S chmod 644 /root/.composer/config.json

# Étape 4: Lancer l'installation
echo "Lancement de l'installation..."
echo "$SSH_PASSWORD" | sudo -S bash -c 'export COMPOSER_ALLOW_SUPERUSER=1; ./install'

# Étape 5: Démarrer le service RemoteLabz Worker
echo "Démarrage du service RemoteLabz Worker..."
echo "$SSH_PASSWORD" | sudo -S systemctl restart remotelabz-worker
echo "$SSH_PASSWORD" | sudo -S systemctl restart remotelabz-worker-network

# Étape 6: Vérifier le statut du service
echo "Vérification du service..."
echo "$SSH_PASSWORD" | sudo -S systemctl status remotelabz-worker --no-pager
echo "$SSH_PASSWORD" | sudo -S systemctl status remotelabz-worker-network --no-pager

# Étape 7: Configurer messenger.yaml pour les binding_keys
echo "Configuration du messenger.yaml pour les binding_keys..."
MESSENGER_CONFIG="/opt/remotelabz-worker/config/packages/messenger.yaml"
if [ -f "$MESSENGER_CONFIG" ]; then
    # Vérifier si la configuration existe déjà
    if ! grep -q "messages_worker1" "$MESSENGER_CONFIG"; then
        # Ajouter la configuration pour le worker
        echo "$SSH_PASSWORD" | sudo -S sed -i '/queues:/a \                    messages_worker1:\n                        binding_keys: ['$WORKER_SERVER']' "$MESSENGER_CONFIG"
        echo "Configuration du messenger.yaml mise à jour."
    else
        echo "Configuration du messenger.yaml déjà présente."
    fi
else
    echo "ATTENTION: Fichier messenger.yaml non trouvé à l'emplacement attendu."
fi

# S'assurer que les permissions sont correctes
echo "Vérification des permissions..."
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz-worker/config/jwt 2>/dev/null || true
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz-worker/var 2>/dev/null || true

echo "Installation terminée avec succès!"
EOF
chmod +x $TEST_SCRIPT

echo "Script de test créé: $TEST_SCRIPT"

# Tester l'exécution du script via SSH
echo "Test d'exécution du script via SSH..."
sshpass -p "$SSH_PASSWORD" ssh -p "$SSH_PORT" -o StrictHostKeyChecking=no "$SSH_USERNAME@$WORKER_SERVER" 'bash -s' < $TEST_SCRIPT "$WORKER_SERVER" "$BRANCH" "$SSH_PASSWORD" "$PUBLIC_ADDRESS" "$SSH_USERNAME" "$SYSTEM_EMAIL"
SSH_EXIT_CODE=$?

if [ $SSH_EXIT_CODE -eq 0 ]; then
    echo "Test d'exécution du script via SSH: OK (code de retour: $SSH_EXIT_CODE)"
else
    echo "Test d'exécution du script via SSH: ÉCHEC (code de retour: $SSH_EXIT_CODE)"
    exit 1
fi

# Nettoyer
rm -f $TEST_SCRIPT
echo "Script de test supprimé: $TEST_SCRIPT"

echo "=== Tous les tests ont réussi ==="
exit 0
