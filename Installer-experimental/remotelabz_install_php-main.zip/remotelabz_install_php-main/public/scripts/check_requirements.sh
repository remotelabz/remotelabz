#!/bin/bash

echo "🔍 Vérification des prérequis..."
# Vérifier si l'extension SSH2 est installée
if php -m | grep -q 'ssh2'; then
    echo "✅ Extension SSH2 installée."
else
    echo "❌ Extension SSH2 non installée."
    echo "💡 Essayer cette commande pour l'installer : sudo bash public/scripts/install_requirements.sh"
fi