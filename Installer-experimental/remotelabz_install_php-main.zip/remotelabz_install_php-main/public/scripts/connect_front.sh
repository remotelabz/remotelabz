#!/bin/bash
# /remoteLabz-installer/scripts/connect_front.sh
# Usage: connect_front.sh <public_address> <ssh_username> <ssh_password> <api_key> <rabbitmq_user> <rabbitmq_pass> <jwt_passphrase> <branch> <db_root_pass> <db_user_pass> <openvpn_passphrase> <system_email>

PUBLIC_ADDRESS=$1
SSH_USERNAME=$2
SSH_PASSWORD=$3
API_KEY=$4
RABBITMQ_USER=$5
RABBITMQ_PASS=$6
JWT_PASSPHRASE=$7
BRANCH=$8
DB_ROOT_PASS=$9
DB_USER_PASS=${10}
OPENVPN_PASSPHRASE=${11}
SYSTEM_EMAIL=${12}

echo "Connexion SSH à la machine Front ($PUBLIC_ADDRESS)..."
sshpass -p "$SSH_PASSWORD" ssh -o StrictHostKeyChecking=no "$SSH_USERNAME@$PUBLIC_ADDRESS" 'bash -s' < ../scripts/install_front.sh "$PUBLIC_ADDRESS" "$SSH_PASSWORD" "$RABBITMQ_USER" "$RABBITMQ_PASS" "$JWT_PASSPHRASE" "$BRANCH" "$DB_ROOT_PASS" "$DB_USER_PASS" "$OPENVPN_PASSPHRASE" "$SYSTEM_EMAIL"

echo "🔌 Connexion SSH à la machine Front ($PUBLIC_ADDRESS)..."
sshpass -p "$SSH_PASSWORD" ssh -p "$SSH_PORT" -o StrictHostKeyChecking=no "$SSH_USERNAME@$PUBLIC_ADDRESS" 'bash -s' < ../scripts/install_front.sh "$PUBLIC_ADDRESS" "$RABBITMQ_USER" "$RABBITMQ_PASS" "$JWT_PASSPHRASE" "$BRANCH"
if [ $? -eq 0 ]; then
    echo "✅ Connexion SSH à la machine Front ($PUBLIC_ADDRESS) réussie."
else
    echo "❌ Erreur: Connexion SSH à la machine Front ($PUBLIC_ADDRESS) échouée."
    exit 1
fi