#!/bin/bash
# test_ssh.sh
# Script pour tester la connexion SSH au serveur worker

# Récupérer les paramètres en arguments
WORKER_SERVER="${1:-127.0.0.1}"
SSH_USERNAME="${2:-remotelabz}"
SSH_PASSWORD="${3:-password}"
SSH_PORT="${4:-22}"

echo "=== Test de connexion SSH ==="
echo "Serveur: $WORKER_SERVER"
echo "Utilisateur: $SSH_USERNAME"
echo "Port: $SSH_PORT"

# Vérifier la connectivité réseau avec plus de détails
echo "Test de ping vers $WORKER_SERVER..."
ping -c 1 -W 5 $WORKER_SERVER
if [ $? -eq 0 ]; then
    echo "✅ Ping OK"
else
    echo "❌ ÉCHEC - Impossible de joindre le serveur"
    echo "  → Vérifiez que le serveur est en ligne et accessible"
    echo "  → Vérifiez votre connexion réseau"
    exit 1
fi

# Vérifier que sshpass est installé
echo -n "Vérification de sshpass: "
if command -v sshpass &> /dev/null; then
    echo "✅ OK"
else
    echo "❌ ÉCHEC - sshpass n'est pas installé"
    echo "  → Installez sshpass avec: sudo apt-get install sshpass"
    exit 1
fi

# Vérifier que netcat est installé
echo -n "Vérification de netcat: "
if ! command -v nc &> /dev/null; then
    echo "❌ ÉCHEC - netcat n'est pas installé"
    echo "  → Installation de netcat..."
    sudo apt-get install -y netcat
fi

# Vérifier que le port SSH est ouvert avec plus de détails
echo "Vérification du port SSH ($SSH_PORT)..."
nc -zv -w 5 $WORKER_SERVER $SSH_PORT
if [ $? -eq 0 ]; then
    echo "✅ Port SSH OK"
else
    echo "❌ ÉCHEC - Le port $SSH_PORT est fermé"
    echo "  → Test avec telnet..."
    timeout 5 telnet $WORKER_SERVER $SSH_PORT
    echo "  → Vérifiez que le service SSH est démarré"
    echo "  → Vérifiez que le port configuré est correct"
    echo "  → Vérifiez les règles de pare-feu"
    echo "  → Si vous utilisez VirtualBox, vérifiez la redirection de port"
    exit 1
fi

# Tester la connexion SSH simple avec verbosité
echo "Test de connexion SSH..."
sshpass -p "$SSH_PASSWORD" ssh -v -p "$SSH_PORT" -o StrictHostKeyChecking=no -o ConnectTimeout=10 "$SSH_USERNAME@$WORKER_SERVER" "echo 'Connexion SSH réussie'"
if [ $? -eq 0 ]; then
    echo "✅ Test de connexion SSH: OK"
else
    echo "❌ Test de connexion SSH: ÉCHEC"
    echo "  → Vérifiez les identifiants SSH"
    echo "  → Vérifiez que l'utilisateur a les permissions nécessaires"
    echo "  → Vérifiez la configuration SSH dans /etc/ssh/sshd_config"
    exit 1
fi

echo "✅ Tous les tests ont réussi"
exit 0
