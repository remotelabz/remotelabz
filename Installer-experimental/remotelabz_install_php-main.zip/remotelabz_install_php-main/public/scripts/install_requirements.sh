#!/bin/bash

echo "Installation des prérequis..."

# Mise à jour des paquets
apt-get update

# Installation des paquets système requis
apt-get install -y \
    git \
    curl \
    unzip \
    libzip-dev \
    libxml2-dev \
    libonig-dev \
    libpng-dev \
    libjpeg-dev \
    libfreetype6-dev \
    libssl-dev \
    libmcrypt-dev \
    libssh2-1-dev \
    php-pear \
    php-dev \
    sshpass \
    php8.1-ssh2 \
    php8.1-pdo \
    php8.1-mysql \
    php8.1-openssl \
    php8.1-json \
    php8.1-curl \
    php8.1-mbstring \
    php8.1-xml \
    php8.1-zip \
    php8.1-gd \
    php8.1-fpm

# Installation de Composer
if ! command -v composer &> /dev/null; then
    echo "Installation de Composer..."
    curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
fi

# Activation des extensions PHP
phpenmod pdo_mysql
phpenmod openssl
phpenmod json
phpenmod curl
phpenmod mbstring
phpenmod xml
phpenmod zip
phpenmod gd
phpenmod ssh2

# Redémarrage de PHP-FPM
systemctl restart php8.1-fpm

# Vérification des versions et extensions
echo "Vérification des installations..."
php -v
echo "Extensions PHP installées :"
php -m

echo "Installation des prérequis terminée."