#!/bin/bash
# /remoteLabz-installer/scripts/install_worker.sh
# Usage: install_worker.sh <worker_server> <branch> <sudo_password> <public_address> <system_email>
# Ce script est exécuté sur la machine worker via SSH par connect_worker.sh

set -e

WORKER_SERVER=$1
BRANCH=$2
SSH_PASSWORD=$3
PUBLIC_ADDRESS=$4
SYSTEM_EMAIL=$5

# Créer un fichier de log
LOG_FILE="/tmp/worker_install.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "=== Installation du Worker RemoteLabz ==="
echo "Serveur: $WORKER_SERVER"
echo "Branch: $BRANCH"
echo "Public Address: $PUBLIC_ADDRESS"
echo "System Email: $SYSTEM_EMAIL"

# Tester l'autorisation sudo
if echo "$SSH_PASSWORD" | sudo -S echo "✅ Autorisation sudo validée" 2>/dev/null; then
    echo "✅ Autorisation sudo validée avec le mot de passe fourni"
else
    echo "⚠️ Échec de l'autorisation sudo avec le mot de passe fourni"
    echo "⚠️ L'installation risque d'échouer"
fi

# Étape 1: Récupérer le code source du worker
if [ -d "$HOME/remotelabz-worker" ]; then
    echo "Le répertoire ~/remotelabz-worker existe déjà. Sauvegarde et suppression..."
    timestamp=$(date +%Y%m%d%H%M%S)
    backup_dir="$HOME/remotelabz-worker-backup-$timestamp"
    mv "$HOME/remotelabz-worker" "$backup_dir"
    echo "Sauvegarde effectuée dans $backup_dir"
fi

echo "Clonage du dépôt Worker depuis la branche $BRANCH..."
cd $HOME
git clone https://github.com/remotelabz/remotelabz-worker.git --branch "$BRANCH" --single-branch

# Étape 2: Installation de l'application RemoteLabz worker
echo "Copie du fichier .env en .env.local..."
cd $HOME/remotelabz-worker
cp .env .env.local

# Étape 3: Modifier le fichier .env.local selon l'environnement
echo "Configuration des paramètres dans .env.local..."
ADM_INTERFACE=$(ip route | grep default | awk '{print $5}')
# Pas besoin de sudo pour ces modifications car le fichier .env.local est dans le home
sed -i "s/ADM_INTERFACE=.*/ADM_INTERFACE=$ADM_INTERFACE/" .env.local
sed -i "s/FRONT_SERVER_IP=.*/FRONT_SERVER_IP=$PUBLIC_ADDRESS/" .env.local
sed -i "s/CONTACT_MAIL=.*/CONTACT_MAIL=$SYSTEM_EMAIL/" .env.local
sed -i "s/SSH_USER_PASSWD=.*/SSH_USER_PASSWD=$SSH_PASSWORD/" .env.local
sed -i "s#SSH_USER_PRIVATEKEY_FILE=.*#SSH_USER_PRIVATEKEY_FILE=$HOME/.ssh/id_rsa#" .env.local
sed -i "s#SSH_USER_PUBLICKEY_FILE=.*#SSH_USER_PUBLICKEY_FILE=$HOME/.ssh/id_rsa.pub#" .env.local
sed -i "s/REMOTELABZ_PROXY_URL=.*/REMOTELABZ_PROXY_URL=http:\/\/$PUBLIC_ADDRESS/" .env.local
sed -i "s/SYSTEM_EMAIL=.*/SYSTEM_EMAIL=$SYSTEM_EMAIL/" .env.local

echo "Configuration de .env.local terminée."

# Étape 4: Lancer l'installation
echo "Lancement de l'installation..."
# Utiliser le mot de passe fourni avec sudo -S
echo "$SSH_PASSWORD" | sudo -S ./install

# Étape 5: Configurer messenger.yaml pour les binding_keys
echo "Configuration du messenger.yaml pour les binding_keys..."
MESSENGER_CONFIG="/opt/remotelabz-worker/config/packages/messenger.yaml"
if [ -f "$MESSENGER_CONFIG" ]; then
    # Vérifier si la configuration existe déjà
    if ! grep -q "messages_worker1" "$MESSENGER_CONFIG"; then
        # Ajouter la configuration pour le worker
        echo "$SSH_PASSWORD" | sudo -S sed -i '/queues:/a \                    messages_worker1:\n                        binding_keys: ['$WORKER_SERVER']' "$MESSENGER_CONFIG"
        echo "Configuration du messenger.yaml mise à jour."
    else
        echo "Configuration du messenger.yaml déjà présente."
    fi
else
    echo "ATTENTION: Fichier messenger.yaml non trouvé à l'emplacement attendu."
fi

# Étape 6: Vérifier la synchronisation NTP
echo "Vérification de la synchronisation temporelle (NTP)..."
if ! command -v ntpstat &> /dev/null && ! command -v timedatectl &> /dev/null; then
    echo "ATTENTION: Aucun service de synchronisation temporelle (NTP) détecté."
    echo "Il est fortement recommandé d'installer et configurer NTP pour assurer le bon fonctionnement de RemoteLabz."
    echo "Vous pouvez installer NTP avec: echo '$SSH_PASSWORD' | sudo -S apt-get install -y ntp"
else
    echo "Service de synchronisation temporelle détecté."
fi

# Étape 7: Démarrer le service RemoteLabz Worker
echo "Démarrage des services RemoteLabz Worker..."
echo "$SSH_PASSWORD" | sudo -S systemctl restart remotelabz-worker
echo "$SSH_PASSWORD" | sudo -S systemctl restart remotelabz-worker-network

# Activer le démarrage automatique des services
echo "Activation du démarrage automatique des services..."
echo "$SSH_PASSWORD" | sudo -S systemctl enable remotelabz-worker
echo "$SSH_PASSWORD" | sudo -S systemctl enable remotelabz-worker-network

# Étape 8: Vérifier le statut du service
echo "Vérification de l'état des services..."
echo "$SSH_PASSWORD" | sudo -S systemctl status remotelabz-worker --no-pager
echo "$SSH_PASSWORD" | sudo -S systemctl status remotelabz-worker-network --no-pager

# S'assurer que les permissions sont correctes
echo "Vérification des permissions..."
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz-worker/config/jwt 2>/dev/null || true
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz-worker/var 2>/dev/null || true

echo "✅ Installation du Worker terminée sur $WORKER_SERVER."
echo "📄 Le fichier de log complet est disponible à l'emplacement : $LOG_FILE"
echo "⚠️ N'oubliez pas de configurer le worker dans l'interface web du Front en ajoutant l'IP $WORKER_SERVER"
exit 0