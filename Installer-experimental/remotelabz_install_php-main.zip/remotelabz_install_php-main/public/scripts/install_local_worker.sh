#!/bin/bash
# Script d'installation du Worker en local (sur la même machine que le Front)
# Ce script est utilisé lorsque l'option "Installation sur la même machine" est sélectionnée

set -e
set -x

# Paramètres
BRANCH="$1"
PUBLIC_ADDRESS="$2"
SYSTEM_EMAIL="$3"
SSH_USERNAME="$4"
SSH_PASSWORD="$5"

# Afficher les paramètres (sans le mot de passe)
echo " Paramètres: BRANCH=$BRANCH, PUBLIC_ADDRESS=$PUBLIC_ADDRESS, SYSTEM_EMAIL=$SYSTEM_EMAIL, SSH_USERNAME=$SSH_USERNAME"

# Créer un fichier de log
LOG_FILE="/tmp/worker_local_install.log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo " Démarrage de l'installation du Worker en local sur la branche $BRANCH"
echo " Log disponible dans $LOG_FILE"

# Tester l'autorisation sudo
if echo "$SSH_PASSWORD" | sudo -S echo "✅ Autorisation sudo validée" 2>/dev/null; then
    echo "✅ Autorisation sudo validée avec le mot de passe fourni"
else
    echo "⚠️ Échec de l'autorisation sudo avec le mot de passe fourni"
    echo "⚠️ L'installation risque d'échouer"
fi

# Vérifier si le répertoire remotelabz-worker existe déjà
if [ -d "$HOME/remotelabz-worker" ]; then
    echo " Le répertoire remotelabz-worker existe déjà. Sauvegarde et suppression..."
    timestamp=$(date +%Y%m%d%H%M%S)
    backup_dir="$HOME/remotelabz-worker-backup-$timestamp"
    mv "$HOME/remotelabz-worker" "$backup_dir"
    echo " Sauvegarde effectuée dans $backup_dir"
fi

# Cloner le dépôt Worker
echo " Clonage du dépôt Worker depuis la branche $BRANCH..."
cd "$HOME"
git clone https://github.com/remotelabz/remotelabz-worker.git --branch "$BRANCH" --single-branch
cd remotelabz-worker

# Copier le fichier .env en .env.local
echo " Copie du fichier .env en .env.local..."
cp .env .env.local

# Configurer les paramètres dans .env.local
echo " Configuration des paramètres dans .env.local..."
ADM_INTERFACE=$(ip route | grep default | awk '{print $5}')

# Utiliser sed sans sudo car fichier dans home
sed -i "s/ADM_INTERFACE=.*/ADM_INTERFACE=$ADM_INTERFACE/" .env.local
sed -i "s/FRONT_SERVER_IP=.*/FRONT_SERVER_IP=$PUBLIC_ADDRESS/" .env.local
sed -i "s/CONTACT_MAIL=.*/CONTACT_MAIL=$SYSTEM_EMAIL/" .env.local
sed -i "s/SSH_USER_PASSWD=.*/SSH_USER_PASSWD=$SSH_PASSWORD/" .env.local
sed -i "s#SSH_USER_PRIVATEKEY_FILE=.*#SSH_USER_PRIVATEKEY_FILE=$HOME/.ssh/id_rsa#" .env.local
sed -i "s#SSH_USER_PUBLICKEY_FILE=.*#SSH_USER_PUBLICKEY_FILE=$HOME/.ssh/id_rsa.pub#" .env.local
sed -i "s/REMOTELABZ_PROXY_URL=.*/REMOTELABZ_PROXY_URL=http:\/\/$PUBLIC_ADDRESS/" .env.local
sed -i "s/SYSTEM_EMAIL=.*/SYSTEM_EMAIL=$SYSTEM_EMAIL/" .env.local

echo " Configuration de .env.local terminée."

# Lancer l'installation selon la documentation
echo " Lancement de l'installation..."
echo "$SSH_PASSWORD" | sudo -S ./install

# Configurer le messenger.yaml pour les binding_keys
echo " Configuration du messenger.yaml pour les binding_keys..."
MESSENGER_CONFIG="/opt/remotelabz-worker/config/packages/messenger.yaml"
if [ -f "$MESSENGER_CONFIG" ]; then
    # Vérifier si la configuration existe déjà
    if ! grep -q "messages_worker1" "$MESSENGER_CONFIG"; then
        # Ajouter la configuration pour le worker local (127.0.0.1)
        echo "$SSH_PASSWORD" | sudo -S sed -i '/queues:/a \                    messages_worker1:\n                        binding_keys: [127.0.0.1]' "$MESSENGER_CONFIG"
        echo " Configuration du messenger.yaml mise à jour."
    else
        echo " Configuration du messenger.yaml déjà présente."
    fi
else
    echo " ATTENTION: Fichier messenger.yaml non trouvé à l'emplacement attendu."
fi

# Vérifier la synchronisation NTP
echo " Vérification de la synchronisation temporelle (NTP)..."
if ! command -v ntpstat &> /dev/null && ! command -v timedatectl &> /dev/null; then
    echo " ATTENTION: Aucun service de synchronisation temporelle (NTP) détecté."
    echo " Il est fortement recommandé d'installer et configurer NTP pour assurer le bon fonctionnement de RemoteLabz."
    echo " Vous pouvez installer NTP avec: echo '$SSH_PASSWORD' | sudo -S apt-get install -y ntp"
else
    echo " Service de synchronisation temporelle détecté."
fi

# Redémarrer les services
echo " Redémarrage des services..."
echo "$SSH_PASSWORD" | sudo -S systemctl restart remotelabz-worker
echo "$SSH_PASSWORD" | sudo -S systemctl restart remotelabz-worker-network

# Vérifier l'état des services
echo " Vérification de l'état des services..."
echo "$SSH_PASSWORD" | sudo -S systemctl status remotelabz-worker --no-pager
echo "$SSH_PASSWORD" | sudo -S systemctl status remotelabz-worker-network --no-pager

# Activer le démarrage automatique des services
echo " Activation du démarrage automatique des services..."
echo "$SSH_PASSWORD" | sudo -S systemctl enable remotelabz-worker
echo "$SSH_PASSWORD" | sudo -S systemctl enable remotelabz-worker-network

# S'assurer que les permissions sont correctes
echo " Vérification des permissions..."
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz-worker/config/jwt 2>/dev/null || true
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz-worker/var 2>/dev/null || true

echo " Installation du Worker en local terminée avec succès!"
echo " N'oubliez pas de configurer le worker dans l'interface web du Front en ajoutant l'IP 127.0.0.1"
exit 0
