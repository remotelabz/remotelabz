#!/bin/bash
# /remoteLabz-installer/scripts/install_front.sh
# Usage: install_front.sh <public_address> <ssh_password> <rabbitmq_user> <rabbitmq_pass> <jwt_passphrase> <branch> <db_root_pass> <db_user_pass> <openvpn_passphrase> <system_email>

PUBLIC_ADDRESS=$1
SSH_PASSWORD=$2
RABBITMQ_USER=$3
RABBITMQ_PASS=$4
JWT_PASSPHRASE=$5
BRANCH=$6
DB_ROOT_PASS=$7
DB_USER_PASS=$8
OPENVPN_PASSPHRASE=$9
SYSTEM_EMAIL=${10}

echo "$SSH_PASSWORD" | sudo -S usermod -a -G www-data $(whoami)

run_step() {
    local step_name="$1"
    local command="$2"
    local fallback_command="$3"
    
    echo "🔄 $step_name..."
    
    # Exécute la commande
    if eval "$command"; then
        echo "✅ $step_name - terminé avec succès."
    else
        echo "⚠️ Erreur lors de: $step_name."
        if [ -n "$fallback_command" ]; then
            echo "🔄 Tentative de récupération..."
            if eval "$fallback_command"; then
                echo "✅ Récupération réussie pour: $step_name."
            else
                echo "❌ Échec de la récupération pour: $step_name. Continuation..."
            fi
        fi
    fi
}

echo "Installation du Front sur $PUBLIC_ADDRESS avec la branche $BRANCH"

# Nettoyage des anciennes installations (si remotelabz déjà cloné pour éviter toute erreur non liée à l'installation du front)
echo "🔄 Nettoyage des anciennes installations..."
if [ -d ~/remotelabz ]; then
    echo "Suppression du dossier ~/remotelabz existant..."
    echo "$SSH_PASSWORD" | sudo -S rm -rf ~/remotelabz
fi

if [ -d ~/remotelabz_temp ]; then
    echo "Suppression du dossier ~/remotelabz_temp existant..."
    echo "$SSH_PASSWORD" | sudo -S rm -rf ~/remotelabz_temp
fi

if [ -d /opt/remotelabz ]; then
    echo "Suppression du dossier /opt/remotelabz existant..."
    echo "$SSH_PASSWORD" | sudo -S rm -rf /opt/remotelabz
fi

echo "✅ Nettoyage terminé."

# Vérifier si l'utilisateur a un dossier personnel
if [ ! -d "/home/$(whoami)" ]; then
    echo "🔄 Création du dossier personnel..."
    echo "$SSH_PASSWORD" | sudo -S mkdir -p /home/$(whoami)
    echo "$SSH_PASSWORD" | sudo -S chown $(whoami):$(whoami) /home/$(whoami)
    echo "✅ Dossier personnel créé."
fi

# Vérifier si MySQL est installé
if ! dpkg -l | grep -q mysql-server; then
    echo "🔄 Installation de MySQL..."
    echo "$SSH_PASSWORD" | sudo -S apt-get update
    echo "$SSH_PASSWORD" | sudo -S apt-get install -y mysql-server
    if [ $? -ne 0 ]; then
        echo "❌ Erreur: Échec de l'installation de MySQL."
        exit 1
    fi
fi

# Vérifier si MySQL est en cours d'exécution
if ! pgrep mysql > /dev/null; then
    echo "🔄 Démarrage de MySQL..."
    echo "$SSH_PASSWORD" | sudo -S service mysql start
    if ! pgrep mysql > /dev/null; then
        echo "❌ Erreur: MySQL n'est pas en cours d'exécution. Veuillez démarrer MySQL avant de continuer."
        exit 1
    fi
fi

# Vérifier si RabbitMQ est en cours d'exécution
if ! pgrep rabbitmq > /dev/null; then
    echo "🔄 Démarrage de RabbitMQ..."
    echo "$SSH_PASSWORD" | sudo -S service rabbitmq-server start
    if ! pgrep rabbitmq > /dev/null; then
        echo "❌ Erreur: RabbitMQ n'est pas en cours d'exécution."
        exit 1
    fi
fi

# Vérifier si OpenVPN est installé
if ! dpkg -l | grep -q openvpn; then
    echo "🔄 Installation de OpenVPN..."
    echo "$SSH_PASSWORD" | sudo -S apt-get install -y openvpn
    if [ $? -ne 0 ]; then
        echo "❌ Erreur: Échec de l'installation de OpenVPN."
        exit 1
    fi
fi

# Supprimer l'ancien dossier EasyRSA s'il existe
if [ -d /etc/openvpn/easy-rsa ]; then
    echo "🔄 Suppression de l'ancien dossier EasyRSA..."
    echo "$SSH_PASSWORD" | sudo -S rm -rf /etc/openvpn/easy-rsa
    if [ $? -ne 0 ]; then
        echo "❌ Erreur: Échec de la suppression de l'ancien dossier EasyRSA."
        exit 1
    fi
fi

# Réinitialiser la PKI
echo "🔄 Réinitialisation de la PKI..."
echo "$SSH_PASSWORD" | sudo -S mkdir -p /etc/openvpn/easy-rsa
if [ $? -ne 0 ]; then
    echo "❌ Erreur: Échec de la création du dossier EasyRSA."
    exit 1
fi
echo "$SSH_PASSWORD" | sudo -S cp -r /usr/share/easy-rsa/* /etc/openvpn/easy-rsa/
if [ $? -ne 0 ]; then
    echo "❌ Erreur: Échec de la copie des fichiers EasyRSA."
    exit 1
fi
cd /etc/openvpn/easy-rsa
echo "$SSH_PASSWORD" | sudo -S ./easyrsa init-pki
if [ $? -ne 0 ]; then
    echo "❌ Erreur: Échec de l'initialisation de la PKI."
    exit 1
fi

# Générer un nouveau certificat CA
echo "🔄 Génération d'un nouveau certificat CA..."
echo "$SSH_PASSWORD" | sudo -S ./easyrsa build-ca nopass
if [ $? -ne 0 ]; then
    echo "❌ Erreur: Échec de la génération du certificat CA."
    exit 1
fi

# Générer les certificats serveur
echo "🔄 Génération des certificats serveur..."
echo "$SSH_PASSWORD" | sudo -S ./easyrsa gen-req RemoteLabz-VPNServer nopass
if [ $? -ne 0 ]; then
    echo "❌ Erreur: Échec de la génération des certificats serveur."
    exit 1
fi

# Désactiver l'invite de confirmation pour la signature du certificat
echo "set_var EASYRSA_BATCH 1" | sudo -S tee /etc/openvpn/easy-rsa/vars

echo "$SSH_PASSWORD" | sudo -S ./easyrsa sign-req server RemoteLabz-VPNServer
if [ $? -ne 0 ]; then
    echo "❌ Erreur: Échec de la signature des certificats serveur."
    exit 1
fi
echo "$SSH_PASSWORD" | sudo -S ./easyrsa gen-dh || echo "⚠️ Échec de la génération des paramètres DH, continuation..."

# Copier les certificats et clés générés
echo "🔄 Copie des certificats et clés générés..."
echo "$SSH_PASSWORD" | sudo -S mkdir -p /etc/openvpn/server
echo "$SSH_PASSWORD" | sudo -S cp /etc/openvpn/easy-rsa/pki/issued/RemoteLabz-VPNServer.crt /etc/openvpn/server/ || echo "Certificat serveur non trouvé, ignoré"
echo "$SSH_PASSWORD" | sudo -S cp /etc/openvpn/easy-rsa/pki/ca.crt /etc/openvpn/server/ || echo "Certificat CA non trouvé, ignoré"
echo "$SSH_PASSWORD" | sudo -S cp /etc/openvpn/easy-rsa/pki/private/ca.key /etc/openvpn/server/ || echo "Clé CA non trouvée, ignorée"
echo "$SSH_PASSWORD" | sudo -S cp /etc/openvpn/easy-rsa/pki/dh.pem /etc/openvpn/server/ || echo "Fichier DH non trouvé, ignoré"

# Vérifier et tuer les processus apt bloquants
echo "🔄 Vérification des processus apt bloquants..."
if pgrep apt > /dev/null || pgrep dpkg > /dev/null; then
    echo "⚠️ Des processus apt/dpkg sont en cours. Tentative de libération des verrous..."
    echo "$SSH_PASSWORD" | sudo -S pkill -9 apt || echo "No apt processes found"
    echo "$SSH_PASSWORD" | sudo -S pkill -9 apt-get || echo "No apt-get processes found"
    echo "$SSH_PASSWORD" | sudo -S pkill -9 dpkg || echo "No dpkg processes found"
    echo "$SSH_PASSWORD" | sudo -S rm -f /var/lib/dpkg/lock || echo "No dpkg lock found"
    echo "$SSH_PASSWORD" | sudo -S rm -f /var/lib/dpkg/lock-frontend || echo "No dpkg frontend lock found"
    echo "$SSH_PASSWORD" | sudo -S rm -f /var/lib/apt/lists/lock || echo "No apt lists lock found"
    echo "$SSH_PASSWORD" | sudo -S rm -f /var/cache/apt/archives/lock || echo "No apt archives lock found"
    echo "$SSH_PASSWORD" | sudo -S dpkg --configure -a || echo "Failed to configure packages"
fi

# 1) Récupérer les sources du Front de Remotelabz
echo "🔄 Clonage du dépôt Remotelabz..."
mkdir -p ~/remotelabz_temp
cd ~/remotelabz_temp
if [ "$BRANCH" == "dev" ]; then
    if ! git clone https://github.com/remotelabz/remotelabz.git --branch "$BRANCH"; then
        echo "❌ Erreur: Échec du clonage du dépôt remotelabz."
        exit 1
    fi
else
    if ! git clone https://github.com/remotelabz/remotelabz.git --branch "$BRANCH" --single-branch; then
        echo "❌ Erreur: Échec du clonage du dépôt remotelabz."
        exit 1
    fi
fi
echo "✅ Clonage du dépôt remotelabz terminé."

# Déplacer le dépôt cloné vers le bon emplacement
echo "$SSH_PASSWORD" | sudo -S cp -r ~/remotelabz_temp/remotelabz ~/remotelabz
cd ~/remotelabz

# 2) Installation des pré-requis
echo "🔄 Installation des pré-requis..."
if ! echo "$SSH_PASSWORD" | sudo -S ./bin/install_requirement.sh; then
    echo "❌ Erreur: Échec de l'installation des prérequis."
    exit 1
fi
echo "✅ Installation des pré-requis terminée."

# 3) Pré-configurations de RabbitMQ et MySQL
# Configuration de RabbitMQ
DEFAULT_RABBITMQ_PASS="password_amqp"
if [ "$RABBITMQ_PASS" != "$DEFAULT_RABBITMQ_PASS" ]; then
    echo "🔄 Modification du mot de passe RabbitMQ..."
    echo "$SSH_PASSWORD" | sudo -S rabbitmqctl change_password 'remotelabz-amqp' "$RABBITMQ_PASS"
    if [ $? -ne 0 ]; then
        echo "❌ Erreur: Échec de la modification du mot de passe RabbitMQ."
        exit 1
    fi
    echo "✅ Mot de passe RabbitMQ modifié."
fi

# Configuration de MySQL
DEFAULT_DB_ROOT_PASS="RemoteLabz-2022$"
DEFAULT_DB_USER_PASS="Mysql-Pa33wrd$"
if [ "$DB_ROOT_PASS" != "$DEFAULT_DB_ROOT_PASS" ]; then
    echo "🔄 Modification du mot de passe root MySQL..."
    echo "$SSH_PASSWORD" | sudo -S mysql -u root -h localhost -e "ALTER USER IF EXISTS 'root'@'localhost' IDENTIFIED BY '$DB_ROOT_PASS'; FLUSH PRIVILEGES;"
    if [ $? -ne 0 ]; then
        echo "❌ Erreur: Échec de la modification du mot de passe root MySQL."
        exit 1
    fi
    echo "✅ Mot de passe root MySQL modifié."
fi

if [ "$DB_USER_PASS" != "$DEFAULT_DB_USER_PASS" ]; then
    echo "🔄 Modification du mot de passe utilisateur MySQL..."
    echo "$SSH_PASSWORD" | sudo -S mysql -u root -h localhost -e "ALTER USER IF EXISTS 'user'@'localhost' IDENTIFIED BY '$DB_USER_PASS'; FLUSH PRIVILEGES;"
    if [ $? -ne 0 ]; then
        echo "❌ Erreur: Échec de la modification du mot de passe utilisateur MySQL."
        exit 1
    fi
    echo "✅ Mot de passe utilisateur MySQL modifié."
fi

# 4) Installation de PHP 7.4
echo "🔄 Installation de PHP 7.4 (Requis par RemoteLabz)..."
echo "$SSH_PASSWORD" | sudo -S apt-get update
echo "$SSH_PASSWORD" | sudo -S apt-get install -y software-properties-common
echo "$SSH_PASSWORD" | sudo -S add-apt-repository -y ppa:ondrej/php
echo "$SSH_PASSWORD" | sudo -S apt-get update
echo "$SSH_PASSWORD" | sudo -S apt-get install -y php7.4 php7.4-cli php7.4-common php7.4-curl php7.4-gd php7.4-intl php7.4-json php7.4-mbstring php7.4-mysql php7.4-xml php7.4-zip php7.4-bcmath php7.4-amqp
echo "$SSH_PASSWORD" | sudo -S apt-get install -y libapache2-mod-php7.4
echo "$SSH_PASSWORD" | sudo -S a2dismod php8.1 || true
echo "$SSH_PASSWORD" | sudo -S a2enmod php7.4
echo "$SSH_PASSWORD" | sudo -S apache2ctl restart
echo "✅ PHP 7.4 installé et configuré."

# 5) Configuration du mail (Exim4)
echo "🔄 Configuration du mail (Exim4)..."
echo "$SSH_PASSWORD" | sudo -S sed -i "s/^root: .*/root: $SYSTEM_EMAIL/" /etc/aliases
echo "$SSH_PASSWORD" | sudo -S newaliases

# Vérifier les alias avec la commande exim -brw root
echo "🔄 Vérification des alias Exim4..."
exim -brw root || true  # Ne pas échouer si la commande échoue

# Modifier le fichier /etc/exim4/exim4.conf.template pour ajouter la configuration de réécriture
echo "🔄 Modification de la configuration de réécriture d'Exim4..."
if [ -f /etc/exim4/exim4.conf.template ]; then
    echo "$SSH_PASSWORD" | sudo -S sed -i "/^begin rewrite/a\\
user@* $SYSTEM_EMAIL FfrsTtcb\\
root@* $SYSTEM_EMAIL FfrsTtcb" /etc/exim4/exim4.conf.template

    # Mettre à jour la configuration d'Exim
    echo "🔄 Mise à jour de la configuration d'Exim..."
    echo "$SSH_PASSWORD" | sudo -S update-exim4.conf

    # Redémarrer le service Exim4
    echo "🔄 Redémarrage du service Exim4..."
    echo "$SSH_PASSWORD" | sudo -S service exim4 restart

    # Vérifier si toutes les adresses sont réécrites avec la commande exim -brw root
    echo "🔄 Vérification de la réécriture des adresses Exim4..."
    exim -brw root || true  # Ne pas échouer si la commande échoue
else
    echo "⚠️ Fichier de configuration Exim4 non trouvé, configuration ignorée."
fi

echo "✅ Configuration du mail (Exim4) terminée."

# 6) Installation manuelle de RemoteLabz
echo "🔄 Installation manuelle de RemoteLabz..."

# Créer le répertoire d'installation
echo "$SSH_PASSWORD" | sudo -S mkdir -p /opt/remotelabz
echo "$SSH_PASSWORD" | sudo -S cp -r ~/remotelabz/* /opt/remotelabz/
echo "$SSH_PASSWORD" | sudo -S cp -r ~/remotelabz/.env /opt/remotelabz/ || true
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz

# Télécharger Composer
echo "🔄 Téléchargement et installation de Composer..."
cd /opt/remotelabz || mkdir -p /opt/remotelabz
echo "$SSH_PASSWORD" | sudo -S curl -sS https://getcomposer.org/installer -o composer-setup.php
echo "$SSH_PASSWORD" | sudo -S php7.4 composer-setup.php --install-dir=/opt/remotelabz/bin/ --filename=composer.phar
echo "$SSH_PASSWORD" | sudo -S rm -f composer-setup.php

# Installer les dépendances avec Composer en définissant explicitement COMPOSER_ALLOW_SUPERUSER
cd /opt/remotelabz
echo "🔄 Installation des dépendances avec Composer (cela peut prendre plusieurs minutes)..."
echo "$SSH_PASSWORD" | sudo -S COMPOSER_ALLOW_SUPERUSER=1 php7.4 -d memory_limit=-1 bin/composer.phar install --no-dev --prefer-dist --no-interaction || echo "⚠️ Échec de l'installation des dépendances, continuation..."

cd /opt/remotelabz
echo "$SSH_PASSWORD" | sudo -S mkdir -p bin
echo "$SSH_PASSWORD" | sudo -S cp composer.phar bin/composer.phar || echo "⚠️ composer.phar non trouvé dans le répertoire courant"
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data bin/

# Ajouter la prise en compte de DEPLOY_SINGLE_SERVER
echo "🔄 Configuration pour un serveur unique (front + worker)..."
echo "DEPLOY_SINGLE_SERVER=1" | sudo -S tee -a /opt/remotelabz/.env.local || echo "⚠️ Échec de l'ajout de DEPLOY_SINGLE_SERVER, continuation..."

# Configuration de la base de données
echo "🔄 Création de la base de données RemoteLabz..."
echo "$SSH_PASSWORD" | sudo -S mysql -uroot -p"$DB_ROOT_PASS" -e "CREATE DATABASE IF NOT EXISTS remotelabz;"
echo "$SSH_PASSWORD" | sudo -S mysql -uroot -p"$DB_ROOT_PASS" -e "GRANT ALL PRIVILEGES ON remotelabz.* TO 'user'@'localhost';"
echo "$SSH_PASSWORD" | sudo -S mysql -uroot -p"$DB_ROOT_PASS" -e "FLUSH PRIVILEGES;"

# Configuration du fichier .env.local
echo "🔄 Configuration du fichier .env.local..."
cat > /tmp/.env.local << EOF
APP_ENV=prod
APP_SECRET=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)
PUBLIC_ADDRESS="$PUBLIC_ADDRESS"
DATABASE_URL=mysql://user:$DB_USER_PASS@127.0.0.1:3306/remotelabz
MESSENGER_TRANSPORT_DSN=amqp://remotelabz-amqp:$RABBITMQ_PASS@127.0.0.1:5672/%2f
SSL_CA_KEY_PASSPHRASE="$OPENVPN_PASSPHRASE"
DEPLOY_SINGLE_SERVER=1
JWT_SECRET_KEY=%kernel.project_dir%/config/jwt/private.pem
JWT_PUBLIC_KEY=%kernel.project_dir%/config/jwt/public.pem
JWT_PASSPHRASE="$JWT_PASSPHRASE"
EOF

echo "$SSH_PASSWORD" | sudo -S cp /tmp/.env.local /opt/remotelabz/.env.local
echo "$SSH_PASSWORD" | sudo -S chown www-data:www-data /opt/remotelabz/.env.local

# Compilation des assets et initialisation de la base de données
echo "🔄 Compilation des assets..."
cd /opt/remotelabz
echo "$SSH_PASSWORD" | sudo -S mkdir -p /opt/remotelabz/var || echo "⚠️ Échec de la création du répertoire var, continuation..."
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz/var || echo "⚠️ Échec de la modification des permissions du répertoire var, continuation..."
echo "$SSH_PASSWORD" | sudo -S php7.4 bin/console assets:install --symlink || echo "⚠️ Échec de l'installation des assets, continuation..."

# Correction de la ligne problématique qui provoquait une erreur de syntaxe 0
echo "🔄 Création du schéma de base de données..."
cd /opt/remotelabz

# Utilisation de la commande doctrine:schema:create sans l'option --force qui n'existe pas
echo "$SSH_PASSWORD" | sudo -S php7.4 bin/console doctrine:schema:create || echo "⚠️ Échec de la création du schéma, continuation..."
echo "$SSH_PASSWORD" | sudo -S php7.4 bin/console doctrine:fixtures:load --no-interaction || echo "⚠️ Échec du chargement des fixtures, continuation..."

# 7) Générer les clés API (JWT)
echo "🔄 Génération des clés API (JWT)..."
cd /opt/remotelabz
echo "$SSH_PASSWORD" | sudo -S mkdir -p config/jwt
echo "$SSH_PASSWORD" | sudo -S timeout 120 openssl genpkey -out config/jwt/private.pem -aes256 -algorithm rsa -pkeyopt rsa_keygen_bits:2048 -pass pass:"$JWT_PASSPHRASE" || echo "⚠️ Échec de la génération de la clé privée, continuation..."
echo "$SSH_PASSWORD" | sudo -S timeout 60 openssl pkey -in config/jwt/private.pem -out config/jwt/public.pem -pubout -passin pass:"$JWT_PASSPHRASE" || echo "⚠️ Échec de la génération de la clé publique, continuation..."
echo "✅ Clés API (JWT) générées et configurées."

# 8) Configurer les permissions des répertoires
echo "🔄 Configuration des permissions des répertoires..."
echo "$SSH_PASSWORD" | sudo -S mkdir -p /opt/remotelabz/var/cache /opt/remotelabz/var/log
echo "$SSH_PASSWORD" | sudo -S chmod -R 775 /opt/remotelabz/var
echo "$SSH_PASSWORD" | sudo -S chmod -R 775 /opt/remotelabz/public
echo "$SSH_PASSWORD" | sudo -S chmod -R 775 /opt/remotelabz/config
echo "$SSH_PASSWORD" | sudo -S chown -R www-data:www-data /opt/remotelabz

# 9) Configuration Apache (permettant l'accès à tous les users)
echo "🔄 Configuration d'Apache pour RemoteLabz..."
cat > /tmp/remotelabz.conf << EOF
<VirtualHost *:80>
    ServerName $PUBLIC_ADDRESS
    DocumentRoot /opt/remotelabz/public

    <Directory /opt/remotelabz/public>
        AllowOverride All
        Require all granted
        FallbackResource /index.php
    </Directory>

    ErrorLog \${APACHE_LOG_DIR}/remotelabz_error.log
    CustomLog \${APACHE_LOG_DIR}/remotelabz_access.log combined
</VirtualHost>
EOF

echo "$SSH_PASSWORD" | sudo -S cp /tmp/remotelabz.conf /etc/apache2/sites-available/remotelabz.conf
echo "$SSH_PASSWORD" | sudo -S a2ensite remotelabz.conf
echo "$SSH_PASSWORD" | sudo -S a2dissite 000-default
echo "$SSH_PASSWORD" | sudo -S a2enmod rewrite
echo "$SSH_PASSWORD" | sudo -S a2enmod php7.4
echo "$SSH_PASSWORD" | sudo -S apache2ctl restart || echo "$SSH_PASSWORD" | sudo -S service apache2 restart || echo "⚠️ Impossible de redémarrer Apache"

echo "✅ Configuration d'Apache terminée."

echo "Installation du Front terminée sur $PUBLIC_ADDRESS"
echo "Vous pouvez accéder à votre instance RemoteLabz à l'adresse: http://$PUBLIC_ADDRESS/"
echo "Utilisateur par défaut : admin@localhost"
echo "Mot de passe par défaut : password"

# À la fin du script, ajoutez cette section de diagnostic
echo "🔄 Vérification de l'installation..."

# Vérifier Apache
run_step "Vérification d'Apache" "echo '$SSH_PASSWORD' | sudo -S apache2ctl status" "echo '$SSH_PASSWORD' | sudo -S service apache2 status"

# Vérifier les permissions du dossier public
run_step "Vérification des permissions" "echo '$SSH_PASSWORD' | sudo -S ls -la /opt/remotelabz/public/" ""

# Vérifier les logs d'erreur Apache
run_step "Vérification des logs d'erreur" "echo '$SSH_PASSWORD' | sudo -S tail -20 /var/log/apache2/remotelabz_error.log" ""

# Tester l'accès à la page d'accueil
run_step "Test d'accès à la page d'accueil" "curl -v http://localhost/ 2>&1 | grep -v '^*' | grep -v '^}'" ""

echo "🔄 Fin de la vérification. Consultez les informations ci-dessus pour diagnostiquer les problèmes."

# À la fin du script, avant le exit 0
echo "🔄 Vérification finale de l'installation..."
# Vérifier si l'autoloader est disponible
if [ -f /opt/remotelabz/vendor/autoload.php ]; then
    echo "✅ Autoloader trouvé - l'installation des dépendances a réussi."
else
    echo "❌ Autoloader non trouvé - l'installation des dépendances a échoué."
    echo "Pour résoudre manuellement ce problème, exécutez :"
    echo "cd /opt/remotelabz && COMPOSER_ALLOW_SUPERUSER=1 php7.4 bin/composer.phar install"
fi

# Vérifier si la base de données est correctement initialisée
echo "🔄 Vérification de la base de données..."
DB_TABLES=$(echo "$SSH_PASSWORD" | sudo -S mysql -uroot -p"$DB_ROOT_PASS" -e "USE remotelabz; SHOW TABLES;" 2>/dev/null)
if [ $? -eq 0 ] && [ -n "$DB_TABLES" ]; then
    echo "✅ Base de données initialisée correctement."
else
    echo "❌ Problème avec l'initialisation de la base de données."
    echo "Pour résoudre manuellement ce problème, exécutez :"
    echo "cd /opt/remotelabz && php7.4 bin/console doctrine:schema:create"
    echo "cd /opt/remotelabz && php7.4 bin/console doctrine:fixtures:load --no-interaction"
fi

# Script de correction automatique en cas d'erreurs persistantes
echo "🔄 Création d'un script de correction automatique..."
cat > ~/fix_remotelabz.sh << 'EOF'
#!/bin/bash
echo "🔄 Script de correction pour RemoteLabz..."
sudo apt-get install -y php7.4-amqp
cd /opt/remotelabz
sudo php7.4 bin/console cache:clear --no-warmup --env=prod
sudo php7.4 bin/console doctrine:schema:create
sudo php7.4 bin/console doctrine:fixtures:load --no-interaction
sudo chown -R www-data:www-data /opt/remotelabz
sudo chmod -R 775 /opt/remotelabz/var

# Correction de la configuration Apache
cat > /tmp/remotelabz.conf << 'EOT'
<VirtualHost *:80>
    ServerName localhost
    DocumentRoot /opt/remotelabz/public

    <Directory /opt/remotelabz/public>
        AllowOverride All
        Require all granted
        FallbackResource /index.php
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/remotelabz_error.log
    CustomLog ${APACHE_LOG_DIR}/remotelabz_access.log combined
</VirtualHost>
EOT
sudo cp /tmp/remotelabz.conf /etc/apache2/sites-available/remotelabz.conf
sudo a2ensite remotelabz.conf
sudo a2dissite 000-default
sudo a2enmod rewrite
sudo apache2ctl restart
echo "✅ Corrections terminées. Vérifiez à nouveau l'accès à http://localhost/"
EOF

chmod +x ~/fix_remotelabz.sh
echo "✅ Script de correction créé à ~/fix_remotelabz.sh. Exécutez-le si nécessaire."

exit 0