<?php
require_once 'includes/config.php';
require_once 'includes/logger.php';

session_start();

$installationSuccess = $_SESSION['installation_success'] ?? false;
$errors = $_SESSION['installation_errors'] ?? [];
$logs = getLastLogs(100); // Récupère les 100 dernières lignes de log
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Résultat de l'installation - RemoteLabz</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Résultat de l'installation RemoteLabz</h1>
        </div>

        <div class="status-box <?php echo $installationSuccess ? 'success' : 'error'; ?>">
            <h2>
                <?php if ($installationSuccess): ?>
                    ✅ Installation terminée avec succès
                <?php else: ?>
                    ❌ L'installation a échoué
                <?php endif; ?>
            </h2>
        </div>

        <?php if ($installationSuccess && isset($_SESSION['worker_config']['same_machine']) && $_SESSION['worker_config']['same_machine'] === 'yes'): ?>
            <div class="info-box">
                <h3>Installation Standalone (Front et Worker sur la même machine)</h3>
                <p>Vous avez choisi d'installer le Front et le Worker sur la même machine. Cette configuration est idéale pour les environnements de test ou les petites installations.</p>
                <p>Points importants à noter :</p>
                <ul>
                    <li>Les services Front et Worker sont tous deux installés sur cette machine</li>
                    <li>Les services devraient démarrer automatiquement</li>
                    <li>Vous pouvez vérifier l'état des services avec les commandes suivantes :</li>
                </ul>
                <div class="code-block">
                    <code>sudo systemctl status remotelabz</code><br>
                    <code>sudo systemctl status remotelabz-worker</code><br>
                    <code>sudo systemctl status remotelabz-worker-network</code>
                </div>
                <p>Pour plus d'informations, consultez la documentation d'installation standalone.</p>
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <h3>Erreurs rencontrées :</h3>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="log-container">
            <h3>Journal d'installation</h3>
            <div class="terminal">
                <?php foreach ($logs as $log): ?>
                    <pre><?php echo htmlspecialchars($log); ?></pre>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="actions">
            <a href="/" class="button">Retour à l'accueil</a>
            <?php if (!$installationSuccess): ?>
                <a href="/install.php" class="button button-secondary">Réessayer l'installation</a>
            <?php endif; ?>
        </div>
    </div>

    <style>
        .status-box {
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
            text-align: center;
        }
        .status-box.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .status-box.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .error-box {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .log-container {
            margin: 20px 0;
        }
        .terminal {
            background-color: #1e1e1e;
            color: #f0f0f0;
            padding: 15px;
            border-radius: 5px;
            max-height: 500px;
            overflow-y: auto;
        }
        .terminal pre {
            margin: 0;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        .button-secondary {
            background-color: #6c757d;
        }
        .button-secondary:hover {
            background-color: #5a6268;
        }
        .info-box {
            background-color: #fff;
            color: #333;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .code-block {
            background-color: #f0f0f0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 10px 0;
        }
        .code-block code {
            font-family: monospace;
            font-size: 14px;
        }
    </style>
</body>
</html>
